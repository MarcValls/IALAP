# Límite material de la verificación HTTP

El servidor HTTP real se inició y respondió correctamente. Chromium no pudo navegar a la URL porque la instalación contiene una política administrada:

```json
{"URLBlocklist": ["*"]}
```

Resultado: `ERR_BLOCKED_BY_ADMINISTRATOR` para `http://127.0.0.1:<puerto>/`.

No se modificó ni eludió la política administrativa. El test E2E está incluido para ejecutarse en otro entorno. La persistencia lógica, serialización y recuperación al reinicializar el documento sí fueron verificadas; la recarga HTTP con `localStorage` nativo no se declara ejecutada aquí.
