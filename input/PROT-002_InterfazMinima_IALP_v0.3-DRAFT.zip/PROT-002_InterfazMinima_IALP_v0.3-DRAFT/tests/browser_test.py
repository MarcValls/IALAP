#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
CHROMIUM = "/usr/bin/chromium"
OUTPUT = Path(os.environ.get("IALP_TEST_OUTPUT", "/tmp/ialp_prot002_v03_results"))


def bundled_html() -> str:
    html = (ROOT / "index.html").read_text(encoding="utf-8")
    css = (ROOT / "assets" / "styles.css").read_text(encoding="utf-8")
    initial = (ROOT / "data" / "initial_state.js").read_text(encoding="utf-8")
    app = (ROOT / "assets" / "app.js").read_text(encoding="utf-8")
    storage_shim = r"""
<script>
  if (!window.__IALP_STORAGE) window.__IALP_STORAGE = {};
  Object.defineProperty(window, "localStorage", {
    configurable: true,
    value: {
      getItem(key) { return Object.prototype.hasOwnProperty.call(window.__IALP_STORAGE, key) ? window.__IALP_STORAGE[key] : null; },
      setItem(key, value) { window.__IALP_STORAGE[key] = String(value); },
      removeItem(key) { delete window.__IALP_STORAGE[key]; },
      clear() { Object.keys(window.__IALP_STORAGE).forEach((key) => delete window.__IALP_STORAGE[key]); }
    }
  });
</script>
"""
    html = html.replace('<link rel="stylesheet" href="assets/styles.css">', f"<style>{css}</style>")
    html = html.replace('<script src="data/initial_state.js"></script>', f"{storage_shim}<script>{initial}</script>")
    html = html.replace('<script src="assets/app.js" defer></script>', f"<script>{app}</script>")
    return html


def load_document(page, content: str) -> None:
    page.set_content(content, wait_until="domcontentloaded")
    page.wait_for_function("window.__IALP_TEST__ && document.querySelector('#executeButton')")
    page.wait_for_timeout(300)


def attach(page, selector: str, name: str, content: bytes, mime: str = "text/plain") -> str:
    page.locator(selector).set_input_files({"name": name, "mimeType": mime, "buffer": content})
    expected = hashlib.sha256(content).hexdigest()
    page.wait_for_function(
        "([selector, expected]) => document.querySelector(selector).textContent.includes(expected)",
        arg=[selector.replace("Input", "State"), expected],
    )
    return expected


def main() -> None:
    OUTPUT.mkdir(parents=True, exist_ok=True)
    content = bundled_html()
    errors: list[str] = []

    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path=CHROMIUM, headless=True)
        context = browser.new_context(viewport={"width": 1440, "height": 1000}, accept_downloads=True)
        page = context.new_page()
        page.on("pageerror", lambda error: errors.append(str(error)))
        load_document(page, content)

        assert page.locator("#chatStatusOutput").inner_text() == "ON"
        assert page.locator("#headerMaturity").inner_text() == "DRAFT"
        assert page.locator("#headerValidation").inner_text() == "PENDING_USER"

        # Ejecución y evidencia textual: aún no es verificación material.
        page.locator("#intentInput").fill("Construir una salida material verificable.")
        page.locator("#executeButton").click()
        page.locator("#productNameInput").fill("Producto v0.3")
        page.locator("#productTypeInput").fill("Archivo de prueba")
        page.locator("#productReferenceInput").fill("local-file:producto-v03.txt")
        page.locator("#productDescriptionInput").fill("Artefacto material para validar el cierre.")
        page.locator("#testNameInput").fill("Prueba de integridad v0.3")
        page.locator("#testStatusSelect").select_option("PASS")
        page.locator("#testEvidenceInput").fill("Resultado reproducible registrado.")
        page.wait_for_timeout(500)
        assert page.locator("#evidenceState").inner_text() == "EVIDENCE_DECLARED"
        assert page.locator("#prepareHandoffButton").is_disabled()

        product_hash = attach(page, "#productArtifactInput", "producto-v03.txt", b"producto material v0.3")
        evidence_hash = attach(page, "#evidenceArtifactInput", "evidencia-v03.txt", b"evidencia material v0.3")
        page.wait_for_timeout(300)
        assert page.locator("#evidenceState").inner_text() == "VERIFIED_MATERIAL"
        state_verified = page.evaluate("window.__IALP_TEST__.getState()")
        run = state_verified["runs"][0]
        assert run["product"]["artifact"]["sha256"] == product_hash
        assert run["evidence"]["artifact"]["sha256"] == evidence_hash

        page.locator("#generateInheritanceButton").click()
        assert product_hash in page.locator("#inheritanceOutput").input_value()
        assert evidence_hash in page.locator("#inheritanceOutput").input_value()
        assert page.locator("#closureCount").inner_text() == "5/5"
        page.locator("#prepareHandoffButton").click()
        assert page.locator("#chatStatusOutput").inner_text() == "HANDOFF"
        assert page.locator("#executeButton").is_disabled()
        handoff_state = page.evaluate("window.__IALP_TEST__.getState()")
        page.add_style_tag(content=".app-header{position:static!important}")
        page.screenshot(path=str(OUTPUT / "PROT-002_v0.3_material_handoff.png"), full_page=True)

        # HANDOFF fabricado: debe ser rechazado.
        forged = json.loads(json.dumps(handoff_state))
        forged["chat"]["closedAt"] = None
        forged["chat"]["closeReason"] = ""
        forged["events"] = [event for event in forged["events"] if event["type"] != "STATE_TRANSITION"]
        forged["inheritanceRecord"] = None
        forged_result = page.evaluate("payload => window.__IALP_TEST__.validateState(payload, {source:'import'})", forged)
        assert forged_result["ok"] is False
        assert any("closedAt" in error or "STATE_TRANSITION" in error or "inheritanceRecord" in error for error in forged_result["errors"])

        # XSS importado: responseHtml no pertenece al esquema y debe rechazarse.
        malicious = json.loads(json.dumps(handoff_state))
        malicious["chat"]["status"] = "ON"
        malicious["chat"]["closedAt"] = None
        malicious["chat"]["closeReason"] = ""
        malicious["events"] = [event for event in malicious["events"] if event["type"] != "STATE_TRANSITION"]
        malicious["inheritance"] = ""
        malicious["inheritanceRecord"] = None
        malicious["runs"][0]["responseHtml"] = '<img src=x onerror="window.__PROT002_XSS__=true">'
        malicious_result = page.evaluate("payload => window.__IALP_TEST__.validateState(payload, {source:'import'})", malicious)
        assert malicious_result["ok"] is False
        assert any("responseHtml" in error for error in malicious_result["errors"])
        assert page.evaluate("window.__PROT002_XSS__ === true") is False

        page.locator("#importInput").set_input_files({
            "name": "malicioso.json",
            "mimeType": "application/json",
            "buffer": json.dumps(malicious).encode("utf-8"),
        })
        page.wait_for_selector("#importDialog[open]")
        assert "Importación rechazada" in page.locator("#importPreview").inner_text()
        assert page.locator("#confirmImportButton").is_disabled()
        page.locator("#importDialog").evaluate("dialog => dialog.close()")
        assert page.evaluate("window.__PROT002_XSS__ === true") is False

        page.locator("#importInput").set_input_files({
            "name": "handoff-fabricado.json",
            "mimeType": "application/json",
            "buffer": json.dumps(forged).encode("utf-8"),
        })
        page.wait_for_selector("#importDialog[open]")
        assert "Importación rechazada" in page.locator("#importPreview").inner_text()
        assert page.locator("#confirmImportButton").is_disabled()
        page.locator("#importDialog").evaluate("dialog => dialog.close()")

        # Incluso un HANDOFF válido se reabre como ON y pierde confianza material al importarse.
        reopened = page.evaluate("payload => window.__IALP_TEST__.normalizeImportedState(payload)", handoff_state)
        assert reopened["chat"]["status"] == "ON"
        assert reopened["chat"]["closedAt"] is None
        assert reopened["inheritance"] == ""
        assert reopened["inheritanceRecord"] is None
        assert reopened["runs"][0]["product"]["artifact"] is None
        assert reopened["runs"][0]["evidence"]["artifact"] is None
        assert reopened["runs"][0]["verificationStatus"] == "EVIDENCE_DECLARED"

        # Importación UI segura del HANDOFF válido.
        page.locator("#importInput").set_input_files({
            "name": "handoff-valido.json",
            "mimeType": "application/json",
            "buffer": json.dumps(handoff_state).encode("utf-8"),
        })
        page.wait_for_selector("#importDialog[open]")
        assert "se reabre como ON" in page.locator("#importPreview").inner_text()
        page.locator("#confirmImportButton").click()
        assert page.locator("#chatStatusOutput").inner_text() == "ON"
        assert page.locator("#evidenceState").inner_text() == "EVIDENCE_DECLARED"
        assert page.locator("#prepareHandoffButton").is_disabled()

        # Persistencia lógica sobre un origen estable simulado: la ventana conserva localStorage al reinicializar el documento.
        page.locator("#intentInput").fill("Estado persistente v0.3")
        page.wait_for_timeout(500)
        before = page.evaluate("window.__IALP_TEST__.getState()")
        load_document(page, content)
        after = page.evaluate("window.__IALP_TEST__.getState()")
        assert after["intent"] == before["intent"] == "Estado persistente v0.3"
        assert len(after["runs"]) == len(before["runs"])

        page.add_style_tag(content=".app-header{position:static!important}")
        page.screenshot(path=str(OUTPUT / "PROT-002_v0.3_desktop.png"), full_page=True)

        mobile = browser.new_context(viewport={"width": 390, "height": 844})
        mobile_page = mobile.new_page()
        load_document(mobile_page, content)
        work_box = mobile_page.locator("#operationPanel").bounding_box()
        context_box = mobile_page.locator(".context-panel").bounding_box()
        assert work_box and context_box and work_box["y"] < context_box["y"]
        assert mobile_page.locator("body").evaluate("el => el.scrollWidth") <= mobile_page.evaluate("window.innerWidth")
        assert mobile_page.locator("details.collapsible[open]").count() == 0
        mobile_page.screenshot(path=str(OUTPUT / "PROT-002_v0.3_mobile.png"), full_page=True)
        mobile.close()

        context.close()
        browser.close()

    if errors:
        raise AssertionError("; ".join(errors))
    print(f"PASS: importación segura, HANDOFF íntegro, SHA-256 material, persistencia lógica y pruebas no destructivas. Resultados: {OUTPUT}")


if __name__ == "__main__":
    main()
