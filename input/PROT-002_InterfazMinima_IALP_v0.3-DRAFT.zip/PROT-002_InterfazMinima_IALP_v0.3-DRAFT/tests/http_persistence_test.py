#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import threading
import urllib.request
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from playwright.sync_api import Error as PlaywrightError
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
CHROMIUM = "/usr/bin/chromium"
OUTPUT = Path(os.environ.get("IALP_TEST_OUTPUT", "/tmp/ialp_prot002_v03_results"))


class QuietHandler(SimpleHTTPRequestHandler):
    def log_message(self, _format: str, *_args: object) -> None:
        return


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--allow-policy-block", action="store_true")
    args = parser.parse_args()
    OUTPUT.mkdir(parents=True, exist_ok=True)

    def factory(*handler_args, **handler_kwargs):
        return QuietHandler(*handler_args, directory=str(ROOT), **handler_kwargs)

    server = ThreadingHTTPServer(("127.0.0.1", 0), factory)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    url = f"http://127.0.0.1:{server.server_port}/"
    result = {
        "url": url,
        "http_server": "PENDING",
        "browser_navigation": "PENDING",
        "native_localStorage_reload": "PENDING",
        "policy_block": None,
    }

    try:
        with urllib.request.urlopen(url, timeout=5) as response:
            body = response.read().decode("utf-8")
            assert response.status == 200
            assert "Interfaz mínima v0.3" in body
            result["http_server"] = "PASS"

        with sync_playwright() as p:
            browser = p.chromium.launch(executable_path=CHROMIUM, headless=True)
            page = browser.new_page()
            try:
                page.goto(url, wait_until="domcontentloaded", timeout=15000)
                page.wait_for_function("window.__IALP_TEST__")
                result["browser_navigation"] = "PASS"
                page.locator("#intentInput").fill("Persistencia HTTP nativa v0.3")
                page.wait_for_timeout(600)
                storage_key = page.evaluate("window.__IALP_TEST__.storageKey")
                raw_before = page.evaluate("key => localStorage.getItem(key)", storage_key)
                assert raw_before and "Persistencia HTTP nativa v0.3" in raw_before
                page.reload(wait_until="domcontentloaded")
                page.wait_for_function("window.__IALP_TEST__")
                assert page.locator("#intentInput").input_value() == "Persistencia HTTP nativa v0.3"
                raw_after = page.evaluate("key => localStorage.getItem(key)", storage_key)
                assert raw_after == raw_before
                result["native_localStorage_reload"] = "PASS"
            except PlaywrightError as error:
                message = str(error)
                if "ERR_BLOCKED_BY_ADMINISTRATOR" in message:
                    result["browser_navigation"] = "BLOCKED_BY_ENVIRONMENT"
                    result["native_localStorage_reload"] = "NOT_EXECUTED"
                    result["policy_block"] = "Chromium URLBlocklist administrada bloquea todas las URL, incluido localhost."
                else:
                    raise
            finally:
                browser.close()
    finally:
        server.shutdown()
        server.server_close()

    output_file = OUTPUT / "http_persistence_result.json"
    output_file.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    if result["native_localStorage_reload"] == "PASS":
        return 0
    return 0 if args.allow_policy_block and result["browser_navigation"] == "BLOCKED_BY_ENVIRONMENT" else 2


if __name__ == "__main__":
    raise SystemExit(main())
