#!/usr/bin/env python3
from __future__ import annotations

import re
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REQUIRED = [
    ROOT / "index.html",
    ROOT / "assets" / "styles.css",
    ROOT / "assets" / "app.js",
    ROOT / "data" / "initial_state.js",
    ROOT / "README.md",
    ROOT / "tests" / "browser_test.py",
    ROOT / "tests" / "http_persistence_test.py",
]


def fail(message: str) -> None:
    print(f"FAIL: {message}")
    raise SystemExit(1)


def main() -> None:
    for path in REQUIRED:
        if not path.is_file():
            fail(f"Falta {path.relative_to(ROOT)}")

    if (ROOT / "data" / "initial_state.json").exists():
        fail("No debe existir una segunda fuente inicial")

    html = (ROOT / "index.html").read_text(encoding="utf-8")
    for reference in ["assets/styles.css", "data/initial_state.js", "assets/app.js"]:
        if reference not in html or not (ROOT / reference).is_file():
            fail(f"Referencia rota: {reference}")

    ids = re.findall(r'id="([^"]+)"', html)
    duplicates = sorted({item for item in ids if ids.count(item) > 1})
    if duplicates:
        fail(f"IDs duplicados: {duplicates}")

    subprocess.run(["node", "--check", str(ROOT / "assets" / "app.js")], check=True)
    subprocess.run(["node", "--check", str(ROOT / "data" / "initial_state.js")], check=True)

    js = (ROOT / "assets" / "app.js").read_text(encoding="utf-8")
    for capability in [
        'SCHEMA_VERSION = "3.0.0"', "normalizeImportedState", "responseHtml",
        "VERIFIED_MATERIAL", "EVIDENCE_DECLARED", "SHA-256", "hashFile",
        "inheritanceRecord", "STATE_IMPORTED_AS_ON", "validateFinalState"
    ]:
        if capability not in js:
            fail(f"Falta capacidad: {capability}")

    if "el.responseOutput.innerHTML = run.responseHtml" in js:
        fail("Permanece el sumidero XSS de responseHtml")
    if '<option value="CANON"' in html:
        fail("CANON no puede aparecer como opción operativa")

    initial = (ROOT / "data" / "initial_state.js").read_text(encoding="utf-8")
    for expected in [
        'schemaVersion: "3.0.0"', 'version: "v0.3"', 'artifactMaturity: "DRAFT"',
        'validationStatus: "PENDING_USER"', 'codeStatus: "PROVISIONAL"', 'status: "ON"'
    ]:
        if expected not in initial:
            fail(f"Fuente inicial incompleta: {expected}")

    print("PASS: estructura v0.3, fuente única, sintaxis, importación segura y evidencia material presentes")


if __name__ == "__main__":
    main()
