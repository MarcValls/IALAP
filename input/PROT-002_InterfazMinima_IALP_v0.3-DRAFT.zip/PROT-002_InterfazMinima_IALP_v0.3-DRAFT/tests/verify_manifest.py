#!/usr/bin/env python3
from __future__ import annotations

import hashlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "MANIFEST.sha256"


def main() -> None:
    if not MANIFEST.is_file():
        raise SystemExit("FAIL: falta MANIFEST.sha256")
    errors: list[str] = []
    for line in MANIFEST.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        expected, relative = line.split("  ", 1)
        path = ROOT / relative
        if not path.is_file():
            errors.append(f"Falta {relative}")
            continue
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        if actual != expected:
            errors.append(f"Hash incorrecto: {relative}")
    if errors:
        raise SystemExit("FAIL: " + "; ".join(errors))
    print("PASS: MANIFEST.sha256 coincide con todos los archivos declarados")


if __name__ == "__main__":
    main()
