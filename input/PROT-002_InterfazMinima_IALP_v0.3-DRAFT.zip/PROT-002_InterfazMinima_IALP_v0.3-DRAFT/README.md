# PROT-002 · Interfaz mínima v0.3-DRAFT

Chat-agente: `IALP-EJEC-InterfazMinima-v0.3-HANDOFF-C06`  
Agente: EJEC · Agente Ejecutor  
Base: PROT-001, CRIT C03 y `IALP-CRIT-InterfazMinima-v0.2-HANDOFF-C05`

## Estado

- Preparado: sí.
- Ejecutado: sí.
- Verificado funcional y adversarialmente: sí, salvo la recarga HTTP nativa bloqueada por la política del entorno.
- Validado por el usuario: no.
- Madurez: `DRAFT`.
- PROT-003: no iniciado.
- Nomenclatura IALP/SRG: `PROVISIONAL`.

## Correcciones de v0.3

1. **Importación segura.** `responseHtml` queda fuera del esquema. La respuesta se representa desde datos estructurados con `textContent`; un JSON no puede insertar HTML activo.
2. **HANDOFF importado.** Un estado final debe superar validación estructural completa y, aun siendo válido, se importa siempre como `ON`. Se eliminan `closedAt`, transición, herencia y confianza material.
3. **Evidencia material.** Producto y prueba requieren archivos locales. La aplicación calcula SHA-256 y registra nombre, tamaño, tipo, fecha y hash.
4. **Estados de evidencia.** `EVIDENCE_DECLARED` significa campos textuales completos; `VERIFIED_MATERIAL` exige dos archivos calculados localmente. Solo este último permite HANDOFF.
5. **Herencia vinculada.** `inheritanceRecord` conserva ejecución, hashes, decisiones, pendientes y texto exacto. HANDOFF verifica toda la correspondencia.
6. **Pruebas no destructivas.** Las capturas y resultados de ejecución se escriben fuera del árbol protegido por `MANIFEST.sha256`.
7. **Persistencia HTTP.** Se incluye un test E2E real con servidor HTTP y recarga nativa. El servidor pasa; Chromium del entorno está bloqueado mediante `URLBlocklist: ["*"]`, por lo que la fase de navegador debe ejecutarse en un equipo sin esa política.

## Ejecución

```bash
python3 -m http.server 8080
```

Abrir `http://localhost:8080`.

## Flujo de HANDOFF

1. Ejecutar una operación.
2. Completar producto, referencia y descripción.
3. Adjuntar el archivo material del producto; se calcula SHA-256.
4. Registrar prueba y resultado `PASS`.
5. Adjuntar el archivo material de evidencia; se calcula SHA-256.
6. Generar herencia vinculada a ambos hashes.
7. Preparar HANDOFF.

Un JSON importado no puede conservar HANDOFF ni los hashes como evidencia confiable: debe readjuntar los archivos localmente.

## Pruebas

```bash
python3 tests/smoke_test.py
IALP_TEST_OUTPUT=/tmp/ialp-v03 python3 tests/browser_test.py
IALP_TEST_OUTPUT=/tmp/ialp-v03 python3 tests/http_persistence_test.py
python3 tests/verify_manifest.py
```

`browser_test.py` es no destructivo. `http_persistence_test.py` devuelve código `2` cuando una política administrativa impide navegar a localhost. Para documentar ese límite sin convertirlo en PASS:

```bash
python3 tests/http_persistence_test.py --allow-policy-block
```

## Límites

La aplicación no ejecuta modelos, comandos ni pruebas externas. El hash acredita que un archivo concreto fue seleccionado y leído localmente; no convierte automáticamente su contenido en verdadero ni sustituye la revisión CRIT o la validación del usuario.
