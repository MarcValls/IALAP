(() => {
  "use strict";

  const STORAGE_KEY = "ialp-prot002-state-v0.3";
  const SCHEMA_VERSION = "3.0.0";
  const CHAT_STATUSES = ["ON", "HANDOFF", "OFF"];
  const FINAL_STATUSES = new Set(["HANDOFF", "OFF"]);
  const VERIFICATION_STATUSES = ["PENDING", "EVIDENCE_DECLARED", "VERIFIED_MATERIAL", "FAIL"];
  const MAX_IMPORT_BYTES = 2 * 1024 * 1024;
  const MAX_ARTIFACT_BYTES = 50 * 1024 * 1024;
  const SHA256_PATTERN = /^[a-f0-9]{64}$/i;

  const AGENTS = [
    { code: "SEM", name: "Agente Semilla", function: "Prepara un arranque mínimo y explícito." },
    { code: "ARQ", name: "Agente Arquitecto", function: "Diseña estructuras, relaciones y lógica." },
    { code: "DOC", name: "Agente Documentador", function: "Convierte avances en documentación reutilizable." },
    { code: "PLAN", name: "Agente Planificador", function: "Traduce objetivos en fases y tareas verificables." },
    { code: "CRIT", name: "Agente Crítico", function: "Detecta riesgos, contradicciones y fallos." },
    { code: "MEM", name: "Agente Memoria", function: "Mantiene continuidad sin convertir propuestas en canon." },
    { code: "EJEC", name: "Agente Ejecutor", function: "Construye, prueba y entrega productos operables." }
  ];

  const INITIAL_STATE = deepClone(window.IALP_INITIAL_STATE);
  const el = {};
  let state = loadState();
  let saveTimer = null;
  let toastTimer = null;
  let pendingImport = null;
  let importSummary = null;

  document.addEventListener("DOMContentLoaded", init);

  function init() {
    bindElements();
    fillSelectors();
    bindEvents();
    configureResponsiveDefaults();
    ensureRuntimeDates();
    renderAll();
    updateSaveLabel("Estado v0.3 preparado");
    exposeTestApi();
  }

  function bindElements() {
    [
      "headerChatStatus", "headerMaturity", "headerValidation", "saveState", "importButton",
      "importInput", "resetButton", "exportButton", "activeAgentTitle", "chatNamePreview",
      "statusIndicator", "lockedBanner", "intentInput", "executeButton", "runCount", "runList",
      "copyResponseButton", "responseOutput", "evidenceState", "productNameInput", "productTypeInput",
      "productReferenceInput", "productDescriptionInput", "productArtifactInput", "productArtifactState",
      "testNameInput", "testStatusSelect", "testEvidenceInput", "evidenceArtifactInput", "evidenceArtifactState",
      "projectCodeInput", "objectInput", "agentSelect", "versionInput", "cycleInput", "chatStatusOutput",
      "sourceCount", "sourceList", "closureCount", "closureChecklist", "addDecisionButton", "decisionsList",
      "addPendingButton", "pendingList", "inheritanceOutput", "copyInheritanceButton",
      "generateInheritanceButton", "prepareHandoffButton", "closeCycleButton", "toast", "resetDialog",
      "confirmResetButton", "closeDialog", "closeForm", "closeReasonInput", "confirmCloseButton",
      "importDialog", "importPreview", "confirmImportButton"
    ].forEach((id) => { el[id] = document.getElementById(id); });
  }

  function fillSelectors() {
    el.agentSelect.replaceChildren(...AGENTS.map((agent) => {
      const option = document.createElement("option");
      option.value = agent.code;
      option.textContent = `${agent.code} · ${agent.name}`;
      return option;
    }));
  }

  function bindEvents() {
    el.intentInput.addEventListener("input", () => {
      state.intent = el.intentInput.value;
      queueSave();
    });
    el.executeButton.addEventListener("click", executeCycle);
    el.copyResponseButton.addEventListener("click", () => {
      copyText(selectedRun()?.responsePlain || "", "Respuesta copiada");
    });

    el.projectCodeInput.addEventListener("input", () => updateIdentity("projectCode", el.projectCodeInput.value));
    el.objectInput.addEventListener("input", () => updateIdentity("object", el.objectInput.value));
    el.agentSelect.addEventListener("change", () => updateIdentity("agent", el.agentSelect.value));
    el.versionInput.addEventListener("input", () => updateIdentity("version", el.versionInput.value));
    el.cycleInput.addEventListener("input", () => updateIdentity("cycle", el.cycleInput.value));

    [
      ["productNameInput", "product", "name"],
      ["productTypeInput", "product", "type"],
      ["productReferenceInput", "product", "reference"],
      ["productDescriptionInput", "product", "description"],
      ["testNameInput", "evidence", "testName"],
      ["testStatusSelect", "evidence", "testStatus"],
      ["testEvidenceInput", "evidence", "result"]
    ].forEach(([elementId, group, key]) => {
      const eventName = elementId === "testStatusSelect" ? "change" : "input";
      el[elementId].addEventListener(eventName, () => updateRunEvidence(group, key, el[elementId].value));
    });

    el.productArtifactInput.addEventListener("change", () => attachArtifact("product", el.productArtifactInput.files?.[0]));
    el.evidenceArtifactInput.addEventListener("change", () => attachArtifact("evidence", el.evidenceArtifactInput.files?.[0]));

    el.addDecisionButton.addEventListener("click", () => addListItem("decisions", "Nueva decisión"));
    el.addPendingButton.addEventListener("click", () => addListItem("pending", "Nuevo pendiente"));
    el.generateInheritanceButton.addEventListener("click", generateInheritance);
    el.copyInheritanceButton.addEventListener("click", () => copyText(state.inheritance, "Herencia copiada"));
    el.prepareHandoffButton.addEventListener("click", prepareHandoff);
    el.closeCycleButton.addEventListener("click", openCloseDialog);

    el.exportButton.addEventListener("click", exportState);
    el.importButton.addEventListener("click", () => el.importInput.click());
    el.importInput.addEventListener("change", handleImportFile);
    el.confirmImportButton.addEventListener("click", confirmImport);

    el.resetButton.addEventListener("click", () => el.resetDialog.showModal());
    el.confirmResetButton.addEventListener("click", resetState);
    el.confirmCloseButton.addEventListener("click", confirmClose);
  }

  function configureResponsiveDefaults() {
    if (window.matchMedia("(max-width: 800px)").matches) {
      document.querySelectorAll("details.collapsible").forEach((details) => { details.open = false; });
    }
  }

  function renderAll() {
    renderHeader();
    renderIdentity();
    renderRuns();
    renderResponse();
    renderEvidence();
    renderSources();
    renderEditableList("decisions", el.decisionsList);
    renderEditableList("pending", el.pendingList);
    renderInheritance();
    applyLockState();
  }

  function renderHeader() {
    el.headerChatStatus.textContent = state.chat.status;
    el.headerMaturity.textContent = state.prototype.artifactMaturity;
    el.headerValidation.textContent = state.prototype.validationStatus;
    el.statusIndicator.textContent = state.chat.status;
    el.statusIndicator.dataset.status = state.chat.status;
    el.chatStatusOutput.textContent = state.chat.status;
    const agent = agentByCode(state.chat.agent);
    el.activeAgentTitle.textContent = `${agent.code} · ${agent.name}`;
    el.chatNamePreview.textContent = state.chat.name;
  }

  function renderIdentity() {
    el.projectCodeInput.value = state.project.code;
    el.objectInput.value = state.chat.object;
    el.agentSelect.value = state.chat.agent;
    el.versionInput.value = state.prototype.version;
    el.cycleInput.value = state.chat.cycle;
    el.intentInput.value = state.intent;
  }

  function renderRuns() {
    el.runCount.textContent = String(state.runs.length);
    el.runList.replaceChildren();
    if (!state.runs.length) {
      el.runList.className = "run-list empty-state";
      const p = document.createElement("p");
      p.textContent = "No existen ejecuciones registradas.";
      el.runList.append(p);
      return;
    }

    el.runList.className = "run-list";
    [...state.runs].reverse().forEach((run) => {
      const button = document.createElement("button");
      button.className = `run-item ${run.id === state.selectedRunId ? "selected" : ""}`;
      button.type = "button";
      button.dataset.runId = run.id;

      const index = document.createElement("span");
      index.className = "run-index";
      index.textContent = String(run.sequence);

      const main = document.createElement("span");
      main.className = "run-main";
      const strong = document.createElement("strong");
      strong.textContent = run.intent;
      const meta = document.createElement("span");
      meta.textContent = `${run.id} · ${formatDate(run.createdAt)}`;
      main.append(strong, meta);

      const status = document.createElement("span");
      status.className = "run-verification";
      status.dataset.status = run.verificationStatus;
      status.textContent = run.verificationStatus;
      button.append(index, main, status);
      button.addEventListener("click", () => {
        state.selectedRunId = run.id;
        clearFileInputs();
        renderRuns();
        renderResponse();
        renderEvidence();
        renderClosureChecklist();
        queueSave();
      });
      el.runList.append(button);
    });
  }

  function renderResponse() {
    const run = selectedRun();
    el.responseOutput.replaceChildren();
    if (!run) {
      el.responseOutput.className = "response-surface empty";
      const p = document.createElement("p");
      p.textContent = "Selecciona o ejecuta una operación para mostrar su respuesta.";
      el.responseOutput.append(p);
      el.copyResponseButton.disabled = true;
      return;
    }

    el.responseOutput.className = "response-surface";
    const meta = document.createElement("div");
    meta.className = "response-meta";
    [
      ["Ejecución", run.id],
      ["Agente", run.agent],
      ["Chat", state.chat.status],
      ["Evidencia", run.verificationStatus]
    ].forEach(([label, value]) => {
      const item = document.createElement("div");
      item.className = "meta-item";
      const span = document.createElement("span");
      span.textContent = label;
      const strong = document.createElement("strong");
      strong.textContent = value;
      item.append(span, strong);
      meta.append(item);
    });

    const intent = document.createElement("p");
    const intentStrong = document.createElement("strong");
    intentStrong.textContent = "Operación solicitada: ";
    intent.append(intentStrong, document.createTextNode(run.intent));

    const agentText = document.createElement("p");
    agentText.textContent = agentByCode(run.agent).function;

    const heading = document.createElement("h3");
    heading.textContent = "Salida local de demostración";
    const list = document.createElement("ul");
    run.response.actions.forEach((action) => {
      const li = document.createElement("li");
      li.textContent = action;
      list.append(li);
    });

    const nextHeading = document.createElement("h3");
    nextHeading.textContent = "Siguiente agente recomendado";
    const next = document.createElement("p");
    next.textContent = run.response.nextAgent;
    const limit = document.createElement("p");
    const small = document.createElement("small");
    small.textContent = run.response.limit;
    limit.append(small);

    el.responseOutput.append(meta, intent, agentText, heading, list, nextHeading, next, limit);
    el.copyResponseButton.disabled = false;
  }

  function renderEvidence() {
    const run = selectedRun();
    const controls = evidenceControls();
    clearFileInputs();
    if (!run) {
      controls.forEach((control) => { control.value = control.tagName === "SELECT" ? "PENDING" : ""; });
      el.evidenceState.textContent = "SIN EJECUCIÓN";
      el.evidenceState.dataset.status = "PENDING";
      el.productArtifactState.textContent = "Sin archivo verificado.";
      el.evidenceArtifactState.textContent = "Sin archivo verificado.";
      controls.forEach((control) => { control.disabled = true; });
      return;
    }

    el.productNameInput.value = run.product.name;
    el.productTypeInput.value = run.product.type;
    el.productReferenceInput.value = run.product.reference;
    el.productDescriptionInput.value = run.product.description;
    el.testNameInput.value = run.evidence.testName;
    el.testStatusSelect.value = run.evidence.testStatus;
    el.testEvidenceInput.value = run.evidence.result;
    el.evidenceState.textContent = run.verificationStatus;
    el.evidenceState.dataset.status = run.verificationStatus;
    el.productArtifactState.textContent = artifactLabel(run.product.artifact);
    el.evidenceArtifactState.textContent = artifactLabel(run.evidence.artifact);

    const locked = isLocked();
    controls.forEach((control) => { control.disabled = locked; });
  }

  function renderSources() {
    el.sourceCount.textContent = String(state.sources.length);
    el.sourceList.replaceChildren(...state.sources.map((source) => {
      const article = document.createElement("article");
      article.className = "source-item";
      const header = document.createElement("header");
      const strong = document.createElement("strong");
      strong.textContent = source.label;
      const status = document.createElement("span");
      status.className = "source-status";
      status.dataset.status = source.status;
      status.textContent = source.status;
      const p = document.createElement("p");
      p.textContent = source.note;
      header.append(strong, status);
      article.append(header, p);
      return article;
    }));
  }

  function renderEditableList(key, container) {
    container.replaceChildren();
    state[key].forEach((value, index) => {
      const wrapper = document.createElement("div");
      wrapper.className = "editable-item";
      const input = document.createElement("input");
      input.value = value;
      input.disabled = isLocked();
      input.setAttribute("aria-label", `${key === "decisions" ? "Decisión" : "Pendiente"} ${index + 1}`);
      input.addEventListener("input", () => {
        state[key][index] = input.value;
        invalidateInheritance("Continuidad modificada");
        renderClosureChecklist();
        queueSave();
      });
      const remove = document.createElement("button");
      remove.type = "button";
      remove.className = "remove-button";
      remove.textContent = "×";
      remove.disabled = isLocked();
      remove.setAttribute("aria-label", `Eliminar ${key === "decisions" ? "decisión" : "pendiente"}`);
      remove.addEventListener("click", () => {
        state[key].splice(index, 1);
        invalidateInheritance("Continuidad modificada");
        renderEditableList(key, container);
        renderClosureChecklist();
        queueSave();
      });
      wrapper.append(input, remove);
      container.append(wrapper);
    });
  }

  function renderInheritance() {
    el.inheritanceOutput.value = state.inheritance;
    el.copyInheritanceButton.disabled = !state.inheritance;
  }

  function closureCriteria() {
    const run = selectedRun();
    const continuityReady = nonEmpty(state.decisions) && nonEmpty(state.pending);
    const record = state.inheritanceRecord;
    const inheritanceReady = Boolean(run) && Boolean(record) &&
      record.runId === run.id && record.productSha256 === run.product.artifact?.sha256 &&
      record.evidenceSha256 === run.evidence.artifact?.sha256 && record.text === state.inheritance &&
      JSON.stringify(record.decisions) === JSON.stringify(state.decisions) &&
      JSON.stringify(record.pending) === JSON.stringify(state.pending);
    return [
      { key: "run", label: "Existe una ejecución seleccionada.", pass: Boolean(run) },
      { key: "product", label: "El producto tiene datos completos y archivo SHA-256.", pass: Boolean(run) && productComplete(run) && materialArtifactComplete(run.product.artifact) },
      { key: "evidence", label: "La prueba está en PASS y posee archivo de evidencia SHA-256.", pass: Boolean(run) && run.verificationStatus === "VERIFIED_MATERIAL" },
      { key: "continuity", label: "Existen decisiones y pendientes explícitos.", pass: continuityReady },
      { key: "inheritance", label: "La herencia coincide con la ejecución y sus hashes.", pass: inheritanceReady }
    ];
  }

  function renderClosureChecklist() {
    const criteria = closureCriteria();
    const passed = criteria.filter((item) => item.pass).length;
    el.closureCount.textContent = `${passed}/${criteria.length}`;
    el.closureChecklist.replaceChildren(...criteria.map((item) => {
      const li = document.createElement("li");
      li.className = `closure-item ${item.pass ? "pass" : ""}`;
      li.dataset.criterion = item.key;
      li.textContent = item.label;
      return li;
    }));
    el.prepareHandoffButton.disabled = isLocked() || passed !== criteria.length;
    el.generateInheritanceButton.disabled = isLocked() || !canGenerateInheritance();
  }

  function applyLockState() {
    const locked = isLocked();
    document.querySelectorAll(".editable-control").forEach((control) => { control.disabled = locked; });
    [el.intentInput, el.executeButton, el.projectCodeInput, el.objectInput, el.agentSelect, el.versionInput, el.cycleInput]
      .forEach((control) => { control.disabled = locked; });
    evidenceControls().forEach((control) => { control.disabled = locked || !selectedRun(); });

    if (locked) {
      el.lockedBanner.hidden = false;
      el.lockedBanner.textContent = `Ciclo ${state.chat.status} desde ${formatDate(state.chat.closedAt)}. Estado inmovilizado. ${state.chat.closeReason ? `Motivo: ${state.chat.closeReason}` : ""}`;
    } else {
      el.lockedBanner.hidden = true;
      el.lockedBanner.textContent = "";
    }
    renderClosureChecklist();
  }

  function executeCycle() {
    if (isLocked()) {
      showToast(`No se puede ejecutar: el ciclo está ${state.chat.status}`);
      return;
    }
    const intent = el.intentInput.value.trim();
    if (!intent) {
      showToast("Escribe una intención antes de ejecutar");
      el.intentInput.focus();
      return;
    }
    const agent = agentByCode(state.chat.agent);
    const sequence = state.runs.length + 1;
    const id = createRunId(sequence);
    const operation = buildOperation(agent, intent, id, sequence);
    const run = {
      id,
      sequence,
      intent,
      agent: agent.code,
      createdAt: new Date().toISOString(),
      responsePlain: operation.plain,
      response: operation.response,
      product: { name: "", type: "", reference: "", description: "", artifact: null },
      evidence: { testName: "", testStatus: "PENDING", result: "", artifact: null },
      verificationStatus: "PENDING"
    };
    state.runs.push(run);
    state.selectedRunId = run.id;
    state.executionStatus = "EXECUTED";
    state.intent = "";
    state.pending.unshift(`${run.id} · Adjuntar producto y evidencia material.`);
    invalidateInheritance("Nueva ejecución creada");
    addEvent("RUN_EXECUTED", { runId: run.id, intent });
    saveState();
    renderAll();
    showToast(`${run.id} ejecutada y trazada`);
  }

  function buildOperation(agent, intent, id, sequence) {
    const actions = agentActions(agent.code, intent);
    const next = recommendedNext(agent.code);
    const limit = "Esta salida no se considera producto ni evidencia. HANDOFF exige dos archivos locales con hash SHA-256.";
    const plain = [
      `EJECUCIÓN: ${id}`,
      `SECUENCIA: ${sequence}`,
      `OPERACIÓN SOLICITADA: ${intent}`,
      `AGENTE: ${agent.code} · ${agent.name}`,
      `FUNCIÓN: ${agent.function}`,
      "",
      "SALIDA LOCAL DE DEMOSTRACIÓN:",
      ...actions.map((item, index) => `${index + 1}. ${item}`),
      "",
      `SIGUIENTE AGENTE RECOMENDADO: ${next}`,
      "",
      `LÍMITE: ${limit}`
    ].join("\n");
    return { plain, response: { actions, nextAgent: next, limit } };
  }

  function agentActions(code, intent) {
    const shortIntent = intent.length > 110 ? `${intent.slice(0, 110)}…` : intent;
    const map = {
      SEM: [`Delimitar el arranque mínimo para: ${shortIntent}`, "Identificar fuentes imprescindibles y vacíos.", "Preparar herencia inicial sin resolver el sistema completo."],
      ARQ: [`Modelar componentes y relaciones para: ${shortIntent}`, "Separar arquitectura, estado, evidencia e interfaz.", "Definir entradas, salidas y restricciones."],
      DOC: [`Documentar el resultado de: ${shortIntent}`, "Distinguir definido, propuesto, pendiente y descartado.", "Preparar documentación reutilizable."],
      PLAN: [`Convertir en tareas ejecutables: ${shortIntent}`, "Asignar orden, dependencias y aceptación.", "Evitar fases bloqueadas."],
      CRIT: [`Auditar contra el criterio de cierre: ${shortIntent}`, "Buscar contradicciones entre estado y evidencia.", "Emitir GO, NO-GO o GO condicionado."],
      MEM: [`Extraer continuidad relevante de: ${shortIntent}`, "Separar canon, propuesta e inferencia.", "Preparar actualización de memoria sin confirmarla."],
      EJEC: [`Construir un producto concreto para: ${shortIntent}`, "Ejecutar una prueba observable sobre el producto.", "Registrar archivos, hashes, prueba y evidencia."]
    };
    return map[code] || map.EJEC;
  }

  function recommendedNext(code) {
    const map = { SEM: "ARQ", ARQ: "PLAN", PLAN: "EJEC", EJEC: "CRIT", CRIT: "EJEC", DOC: "CRIT", MEM: "SEM" };
    const next = agentByCode(map[code] || "CRIT");
    return `${next.code} · ${next.name}`;
  }

  function updateIdentity(field, value) {
    if (isLocked()) return;
    if (field === "projectCode") state.project.code = sanitizeSegment(value, "IALP");
    if (field === "object") state.chat.object = sanitizeSegment(value, "InterfazMinima");
    if (field === "agent") state.chat.agent = value;
    if (field === "version") state.prototype.version = sanitizeVersion(value);
    if (field === "cycle") state.chat.cycle = sanitizeCycle(value);
    updateChatName();
    invalidateInheritance("Identidad del ciclo modificada");
    renderHeader();
    renderClosureChecklist();
    queueSave();
  }

  function updateRunEvidence(group, key, value) {
    if (isLocked()) return;
    const run = selectedRun();
    if (!run) return;
    run[group][key] = value;
    refreshRunStatus(run, `Campo ${group}.${key} modificado`);
  }

  async function attachArtifact(group, file) {
    if (isLocked() || !file) return;
    const run = selectedRun();
    if (!run) return;
    if (file.size > MAX_ARTIFACT_BYTES) {
      showToast("Archivo rechazado: máximo 50 MB");
      clearFileInputs();
      return;
    }
    updateSaveLabel("Calculando SHA-256…");
    try {
      const sha256 = await hashFile(file);
      const artifact = {
        fileName: file.name,
        size: file.size,
        mimeType: file.type || "application/octet-stream",
        sha256,
        verifiedAt: new Date().toISOString(),
        source: "LOCAL_FILE"
      };
      if (group === "product") {
        run.product.artifact = artifact;
        if (!run.product.reference.trim()) run.product.reference = `local-file:${file.name}`;
      } else {
        run.evidence.artifact = artifact;
        if (!run.evidence.result.trim()) run.evidence.result = `Evidencia material adjunta: ${file.name}`;
      }
      refreshRunStatus(run, `Archivo ${group} verificado por SHA-256`);
      showToast(`${file.name} verificado por SHA-256`);
    } catch (error) {
      console.error(error);
      showToast("No se pudo calcular SHA-256");
      updateSaveLabel("Error de verificación");
    } finally {
      clearFileInputs();
    }
  }

  async function hashFile(file) {
    const bytes = new Uint8Array(await file.arrayBuffer());
    if (globalThis.crypto?.subtle) {
      const digest = await globalThis.crypto.subtle.digest("SHA-256", bytes);
      return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, "0")).join("");
    }
    return sha256Fallback(bytes);
  }

  function sha256Fallback(bytes) {
    const K = [
      0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
      0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
      0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
      0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
      0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
      0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
      0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
      0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2
    ];
    const H = [0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19];
    const bitLength = bytes.length * 8;
    const paddedLength = Math.ceil((bytes.length + 9) / 64) * 64;
    const data = new Uint8Array(paddedLength);
    data.set(bytes);
    data[bytes.length] = 0x80;
    const view = new DataView(data.buffer);
    const high = Math.floor(bitLength / 0x100000000);
    const low = bitLength >>> 0;
    view.setUint32(paddedLength - 8, high);
    view.setUint32(paddedLength - 4, low);
    const w = new Uint32Array(64);
    const rotr = (value, shift) => (value >>> shift) | (value << (32 - shift));
    for (let offset = 0; offset < data.length; offset += 64) {
      for (let i = 0; i < 16; i += 1) w[i] = view.getUint32(offset + i * 4);
      for (let i = 16; i < 64; i += 1) {
        const s0 = rotr(w[i - 15], 7) ^ rotr(w[i - 15], 18) ^ (w[i - 15] >>> 3);
        const s1 = rotr(w[i - 2], 17) ^ rotr(w[i - 2], 19) ^ (w[i - 2] >>> 10);
        w[i] = (w[i - 16] + s0 + w[i - 7] + s1) >>> 0;
      }
      let [a,b,c,d,e,f,g,h] = H;
      for (let i = 0; i < 64; i += 1) {
        const S1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25);
        const ch = (e & f) ^ (~e & g);
        const t1 = (h + S1 + ch + K[i] + w[i]) >>> 0;
        const S0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22);
        const maj = (a & b) ^ (a & c) ^ (b & c);
        const t2 = (S0 + maj) >>> 0;
        h = g; g = f; f = e; e = (d + t1) >>> 0; d = c; c = b; b = a; a = (t1 + t2) >>> 0;
      }
      H[0]=(H[0]+a)>>>0; H[1]=(H[1]+b)>>>0; H[2]=(H[2]+c)>>>0; H[3]=(H[3]+d)>>>0;
      H[4]=(H[4]+e)>>>0; H[5]=(H[5]+f)>>>0; H[6]=(H[6]+g)>>>0; H[7]=(H[7]+h)>>>0;
    }
    return H.map((value) => value.toString(16).padStart(8, "0")).join("");
  }

  function refreshRunStatus(run, reason) {
    run.verificationStatus = deriveVerificationStatus(run);
    state.executionStatus = deriveExecutionStatus(state.runs);
    invalidateInheritance(`${reason} en ${run.id}`);
    addOrUpdateRunPending(run);
    addEvent("RUN_EVIDENCE_UPDATED", { runId: run.id, status: run.verificationStatus, reason });
    saveState();
    renderRuns();
    renderEvidence();
    renderEditableList("pending", el.pendingList);
    renderClosureChecklist();
  }

  function deriveVerificationStatus(run) {
    if (run.evidence.testStatus === "FAIL") return "FAIL";
    if (!productComplete(run) || !evidenceDeclaredComplete(run)) return "PENDING";
    if (materialArtifactComplete(run.product.artifact) && materialArtifactComplete(run.evidence.artifact)) {
      return "VERIFIED_MATERIAL";
    }
    return "EVIDENCE_DECLARED";
  }

  function deriveExecutionStatus(runs) {
    if (runs.some((run) => run.verificationStatus === "VERIFIED_MATERIAL")) return "VERIFIED_MATERIAL";
    if (runs.some((run) => run.verificationStatus === "EVIDENCE_DECLARED")) return "EVIDENCE_DECLARED";
    if (runs.length) return "EXECUTED";
    return "NOT_RUN";
  }

  function productComplete(run) {
    return [run.product.name, run.product.type, run.product.reference, run.product.description]
      .every((value) => String(value || "").trim());
  }

  function evidenceDeclaredComplete(run) {
    return Boolean(String(run.evidence.testName || "").trim()) &&
      Boolean(String(run.evidence.result || "").trim()) &&
      run.evidence.testStatus === "PASS";
  }

  function materialArtifactComplete(artifact) {
    return Boolean(artifact) && artifact.source === "LOCAL_FILE" &&
      Boolean(String(artifact.fileName || "").trim()) && Number.isFinite(Number(artifact.size)) &&
      Number(artifact.size) >= 0 && SHA256_PATTERN.test(String(artifact.sha256 || "")) &&
      isValidIsoDate(artifact.verifiedAt);
  }

  function addOrUpdateRunPending(run) {
    const marker = `${run.id} ·`;
    state.pending = state.pending.filter((item) => !String(item).startsWith(marker));
    if (run.verificationStatus === "VERIFIED_MATERIAL") {
      state.pending.unshift(`${marker} Evidencia material verificada; validación del usuario pendiente.`);
    } else if (run.verificationStatus === "EVIDENCE_DECLARED") {
      state.pending.unshift(`${marker} Texto completo, pero faltan archivos locales con SHA-256.`);
    } else if (run.verificationStatus === "FAIL") {
      state.pending.unshift(`${marker} Corregir el producto: la prueba está en FAIL.`);
    } else {
      state.pending.unshift(`${marker} Completar producto, prueba y archivos de evidencia.`);
    }
  }

  function canGenerateInheritance() {
    const run = selectedRun();
    return Boolean(run) && run.verificationStatus === "VERIFIED_MATERIAL" && nonEmpty(state.decisions) && nonEmpty(state.pending);
  }

  function generateInheritance() {
    if (isLocked()) return;
    if (!canGenerateInheritance()) {
      showToast("HANDOFF exige producto y evidencia material verificados");
      return;
    }
    const run = selectedRun();
    const text = buildInheritance(run);
    state.inheritance = text;
    state.inheritanceRecord = {
      runId: run.id,
      productSha256: run.product.artifact.sha256,
      evidenceSha256: run.evidence.artifact.sha256,
      decisions: [...state.decisions],
      pending: [...state.pending],
      generatedAt: new Date().toISOString(),
      text
    };
    addEvent("INHERITANCE_GENERATED", {
      runId: run.id,
      productSha256: run.product.artifact.sha256,
      evidenceSha256: run.evidence.artifact.sha256
    });
    saveState();
    renderInheritance();
    renderClosureChecklist();
    showToast("Herencia vinculada a los hashes materiales");
  }

  function buildInheritance(run) {
    const next = recommendedNext(state.chat.agent);
    const nomenclatureNote = `${state.project.code}/SRG permanece ${state.project.codeStatus} y no se declara canon.`;
    return [
      "HERENCIA CONTEXTUAL",
      "",
      `Origen: ${state.chat.name}`,
      `Ejecución: ${run.id}`,
      `Estado operativo: ${state.chat.status}`,
      `Madurez del artefacto: ${state.prototype.artifactMaturity}`,
      `Estado de ejecución: ${state.executionStatus}`,
      `Estado de validación: ${state.prototype.validationStatus}`,
      "",
      `Operación solicitada: ${run.intent}`,
      `Producto generado: ${run.product.name}`,
      `Tipo de producto: ${run.product.type}`,
      `Referencia: ${run.product.reference}`,
      `Descripción: ${run.product.description}`,
      `Archivo de producto: ${run.product.artifact.fileName}`,
      `SHA-256 producto: ${run.product.artifact.sha256}`,
      `Prueba ejecutada: ${run.evidence.testName}`,
      `Resultado de prueba: ${run.evidence.testStatus}`,
      `Evidencia obtenida: ${run.evidence.result}`,
      `Archivo de evidencia: ${run.evidence.artifact.fileName}`,
      `SHA-256 evidencia: ${run.evidence.artifact.sha256}`,
      "",
      "Decisiones:",
      ...state.decisions.filter((item) => item.trim()).map((item) => `- ${item}`),
      "",
      "Pendientes:",
      ...state.pending.filter((item) => item.trim()).map((item) => `- ${item}`),
      "",
      `Nota de nomenclatura: ${nomenclatureNote}`,
      `Siguiente agente recomendado: ${next}`,
      "",
      "<<SRG:MEM_UPDATE>>",
      `Origen: ${state.chat.name}`,
      `Definido: ${run.product.name} existe como ${run.product.type} en ${run.product.reference}.`,
      `Ejecutado: ${run.evidence.testName}.`,
      `Verificado: VERIFIED_MATERIAL · producto ${run.product.artifact.sha256} · evidencia ${run.evidence.artifact.sha256}.`,
      `Validado: ${state.prototype.validationStatus}.`,
      `Pendiente: ${state.pending.filter((item) => item.trim()).join(" | ")}`,
      `Riesgos: ${nomenclatureNote}`,
      `Próxima acción: ${next} debe revisar el producto y los hashes registrados.`,
      `Siguiente agente recomendado: ${next}`,
      "<</SRG:MEM_UPDATE>>"
    ].join("\n");
  }

  function prepareHandoff() {
    if (isLocked()) return;
    const failed = closureCriteria().find((item) => !item.pass);
    if (failed) {
      showToast(`HANDOFF bloqueado: ${failed.label}`);
      return;
    }
    const run = selectedRun();
    const closedAt = new Date().toISOString();
    state.chat.status = "HANDOFF";
    state.chat.closedAt = closedAt;
    state.chat.closeReason = "Producto y evidencia material verificados por SHA-256; preparado para revisión CRIT.";
    updateChatName();
    addEvent("STATE_TRANSITION", { from: "ON", to: "HANDOFF", runId: run.id, at: closedAt });
    saveState();
    renderAll();
    showToast("Ciclo inmovilizado en HANDOFF");
  }

  function openCloseDialog() {
    if (isLocked()) return;
    el.closeReasonInput.value = "";
    el.closeDialog.showModal();
  }

  function confirmClose(event) {
    event.preventDefault();
    const reason = el.closeReasonInput.value.trim();
    if (!reason) {
      showToast("El cierre en OFF exige un motivo");
      el.closeReasonInput.focus();
      return;
    }
    const closedAt = new Date().toISOString();
    state.chat.status = "OFF";
    state.chat.closedAt = closedAt;
    state.chat.closeReason = reason;
    updateChatName();
    addEvent("STATE_TRANSITION", { from: "ON", to: "OFF", reason, at: closedAt });
    saveState();
    el.closeDialog.close();
    renderAll();
    showToast("Ciclo cerrado e inmovilizado en OFF");
  }

  function addListItem(key, value) {
    if (isLocked()) return;
    state[key].push(value);
    invalidateInheritance("Continuidad modificada");
    renderEditableList(key, key === "decisions" ? el.decisionsList : el.pendingList);
    renderClosureChecklist();
    queueSave();
  }

  function invalidateInheritance(reason) {
    if (!state.inheritance && !state.inheritanceRecord) return;
    state.inheritance = "";
    state.inheritanceRecord = null;
    addEvent("INHERITANCE_INVALIDATED", { reason });
    renderInheritance();
  }

  function updateChatName() {
    updateNameFor(state);
  }

  function handleImportFile() {
    const file = el.importInput.files?.[0];
    if (!file) return;
    if (file.size > MAX_IMPORT_BYTES) {
      pendingImport = null;
      importSummary = null;
      el.importPreview.textContent = "Importación rechazada: máximo 2 MB.";
      el.confirmImportButton.disabled = true;
      el.importDialog.showModal();
      el.importInput.value = "";
      return;
    }
    const reader = new FileReader();
    reader.addEventListener("load", () => {
      try {
        const parsed = JSON.parse(String(reader.result));
        const validation = validateState(parsed, { source: "import" });
        if (!validation.ok) {
          pendingImport = null;
          importSummary = null;
          renderImportErrors(validation.errors);
          el.confirmImportButton.disabled = true;
        } else {
          const originalStatus = parsed.chat.status;
          pendingImport = normalizeImportedState(parsed);
          importSummary = {
            originalStatus,
            resultingStatus: pendingImport.chat.status,
            clearedMaterialRuns: pendingImport.runs.filter((run) => run.verificationStatus === "EVIDENCE_DECLARED").length
          };
          renderImportPreview(pendingImport, importSummary);
          el.confirmImportButton.disabled = false;
        }
      } catch (error) {
        pendingImport = null;
        importSummary = null;
        renderImportErrors([`JSON no válido: ${error.message}`]);
        el.confirmImportButton.disabled = true;
      }
      el.importDialog.showModal();
      el.importInput.value = "";
    });
    reader.readAsText(file);
  }

  function renderImportErrors(errors) {
    el.importPreview.replaceChildren();
    const p = document.createElement("p");
    p.className = "import-error";
    p.textContent = "Importación rechazada.";
    const ul = document.createElement("ul");
    errors.forEach((error) => {
      const li = document.createElement("li");
      li.textContent = error;
      ul.append(li);
    });
    el.importPreview.append(p, ul);
  }

  function renderImportPreview(candidate, summary) {
    el.importPreview.replaceChildren();
    const p = document.createElement("p");
    p.textContent = `Archivo compatible con el esquema ${SCHEMA_VERSION}. Por seguridad, todo estado importado se reabre como ON y pierde confianza material.`;
    const grid = document.createElement("div");
    grid.className = "import-summary";
    [
      ["Chat de origen", candidate.chat.name],
      ["Estado recibido", summary.originalStatus],
      ["Estado resultante", summary.resultingStatus],
      ["Ejecuciones", String(candidate.runs.length)],
      ["Evidencia degradada", String(summary.clearedMaterialRuns)]
    ].forEach(([label, value]) => {
      const row = document.createElement("div");
      const span = document.createElement("span");
      span.textContent = label;
      const strong = document.createElement("strong");
      strong.textContent = value;
      row.append(span, strong);
      grid.append(row);
    });
    el.importPreview.append(p, grid);
  }

  function confirmImport(event) {
    event.preventDefault();
    if (!pendingImport) return;
    state = pendingImport;
    addEvent("STATE_IMPORTED_AS_ON", {
      originalStatus: importSummary?.originalStatus || "UNKNOWN",
      materialTrustCleared: true,
      schemaVersion: state.schemaVersion
    });
    pendingImport = null;
    importSummary = null;
    saveState();
    el.importDialog.close();
    renderAll();
    showToast("Estado importado como ON; hashes deben verificarse localmente");
  }

  function validateState(candidate, options = {}) {
    const source = options.source || "storage";
    const errors = [];
    if (!candidate || typeof candidate !== "object" || Array.isArray(candidate)) {
      return { ok: false, errors: ["El contenido raíz debe ser un objeto."] };
    }
    if (candidate.schemaVersion !== SCHEMA_VERSION) errors.push(`schemaVersion debe ser ${SCHEMA_VERSION}.`);
    if (!candidate.project || typeof candidate.project !== "object") errors.push("Falta project.");
    if (!candidate.prototype || typeof candidate.prototype !== "object") errors.push("Falta prototype.");
    if (!candidate.chat || typeof candidate.chat !== "object") errors.push("Falta chat.");
    if (!CHAT_STATUSES.includes(candidate.chat?.status)) errors.push("chat.status debe ser ON, HANDOFF u OFF; CANON no es importable.");
    if (!Array.isArray(candidate.runs)) errors.push("runs debe ser una lista.");
    if (!Array.isArray(candidate.decisions)) errors.push("decisions debe ser una lista.");
    if (!Array.isArray(candidate.pending)) errors.push("pending debe ser una lista.");
    if (!Array.isArray(candidate.sources)) errors.push("sources debe ser una lista.");
    if (!Array.isArray(candidate.events)) errors.push("events debe ser una lista.");
    if (candidate.prototype?.id !== "PROT-002") errors.push("prototype.id debe ser PROT-002.");
    if (candidate.prototype?.artifactMaturity !== "DRAFT") errors.push("artifactMaturity debe permanecer DRAFT.");
    if (candidate.prototype?.validationStatus !== "PENDING_USER") errors.push("validationStatus debe permanecer PENDING_USER.");
    if (candidate.project?.codeStatus !== "PROVISIONAL") errors.push("project.codeStatus debe permanecer PROVISIONAL.");

    if (Array.isArray(candidate.runs)) {
      const ids = candidate.runs.map((run) => run?.id).filter(Boolean);
      if (new Set(ids).size !== ids.length) errors.push("Los IDs de ejecución deben ser únicos.");
      candidate.runs.forEach((run, index) => validateRun(run, index, errors, source));
    }

    if (candidate.chat?.status === "OFF") validateFinalState(candidate, "OFF", errors);
    if (candidate.chat?.status === "HANDOFF") validateFinalState(candidate, "HANDOFF", errors);
    return { ok: errors.length === 0, errors };
  }

  function validateRun(run, index, errors, source) {
    const number = index + 1;
    if (!run || typeof run !== "object") {
      errors.push(`La ejecución ${number} debe ser un objeto.`);
      return;
    }
    if (Object.prototype.hasOwnProperty.call(run, "responseHtml")) {
      errors.push(`La ejecución ${number} contiene responseHtml, campo activo no importable.`);
    }
    if (!run.id) errors.push(`La ejecución ${number} no tiene id.`);
    if (!VERIFICATION_STATUSES.includes(run.verificationStatus)) errors.push(`La ejecución ${number} tiene verificationStatus inválido.`);
    if (!run.response || !Array.isArray(run.response.actions) || typeof run.response.nextAgent !== "string" || typeof run.response.limit !== "string") {
      errors.push(`La ejecución ${number} no contiene respuesta estructurada segura.`);
    }
    if (run.response?.actions?.some((action) => typeof action !== "string")) errors.push(`La ejecución ${number} contiene acciones no textuales.`);
    if (run.verificationStatus === "EVIDENCE_DECLARED" && (!productComplete(run) || !evidenceDeclaredComplete(run))) {
      errors.push(`La ejecución ${number} declara EVIDENCE_DECLARED sin datos textuales completos.`);
    }
    if (run.verificationStatus === "VERIFIED_MATERIAL") {
      if (!productComplete(run) || !evidenceDeclaredComplete(run)) errors.push(`La ejecución ${number} declara VERIFIED_MATERIAL sin datos completos.`);
      if (!materialArtifactComplete(run.product?.artifact) || !materialArtifactComplete(run.evidence?.artifact)) {
        errors.push(`La ejecución ${number} declara VERIFIED_MATERIAL sin dos artefactos SHA-256 válidos.`);
      }
    }
    if (source === "import" && containsDangerousText(run)) {
      errors.push(`La ejecución ${number} contiene marcado activo o URLs ejecutables no admitidas.`);
    }
  }

  function validateFinalState(candidate, target, errors) {
    if (!isValidIsoDate(candidate.chat.closedAt)) errors.push(`Un ciclo ${target} requiere closedAt ISO válido.`);
    if (!String(candidate.chat.closeReason || "").trim()) errors.push(`Un ciclo ${target} requiere closeReason.`);
    const transition = candidate.events?.find((event) => event?.type === "STATE_TRANSITION" &&
      event?.detail?.from === "ON" && event?.detail?.to === target);
    if (!transition) {
      errors.push(`Un ciclo ${target} requiere evento STATE_TRANSITION coherente.`);
    } else if (transition.detail?.at !== candidate.chat.closedAt) {
      errors.push(`El evento ${target} debe coincidir exactamente con chat.closedAt.`);
    }
    if (target === "OFF" && transition?.detail?.reason !== candidate.chat.closeReason) {
      errors.push("El motivo del evento OFF debe coincidir con chat.closeReason.");
    }

    if (target === "HANDOFF") {
      const selected = candidate.runs?.find((run) => run?.id === candidate.selectedRunId);
      if (!selected || selected.verificationStatus !== "VERIFIED_MATERIAL") {
        errors.push("Un HANDOFF requiere ejecución seleccionada en VERIFIED_MATERIAL.");
        return;
      }
      if (transition?.detail?.runId !== selected.id) errors.push("El evento HANDOFF debe vincular la ejecución seleccionada.");
      const record = candidate.inheritanceRecord;
      if (!record || record.runId !== selected.id || record.text !== candidate.inheritance) {
        errors.push("Un HANDOFF requiere inheritanceRecord íntegro y vinculado.");
      } else {
        if (!isValidIsoDate(record.generatedAt)) errors.push("inheritanceRecord.generatedAt debe ser una fecha ISO válida.");
        if (record.productSha256 !== selected.product.artifact?.sha256 || record.evidenceSha256 !== selected.evidence.artifact?.sha256) {
          errors.push("Los hashes de inheritanceRecord no coinciden con la ejecución.");
        }
        if (!record.text.includes(selected.id) || !record.text.includes(record.productSha256) || !record.text.includes(record.evidenceSha256)) {
          errors.push("El texto de herencia no contiene la ejecución y los hashes vinculados.");
        }
        if (JSON.stringify(record.decisions) !== JSON.stringify(candidate.decisions) || JSON.stringify(record.pending) !== JSON.stringify(candidate.pending)) {
          errors.push("La continuidad del HANDOFF no coincide con inheritanceRecord.");
        }
      }
      if (!nonEmpty(candidate.decisions) || !nonEmpty(candidate.pending)) errors.push("Un HANDOFF requiere decisiones y pendientes.");
    }
  }

  function containsDangerousText(run) {
    const values = [
      run.responsePlain,
      ...(run.response?.actions || []),
      run.response?.nextAgent,
      run.response?.limit
    ].map((value) => String(value || "").toLowerCase());
    return values.some((value) => /<\s*(script|iframe|svg|img|object|embed)|on\w+\s*=|javascript\s*:|data\s*:\s*text\/html/.test(value));
  }

  function normalizeState(candidate) {
    const base = deepClone(INITIAL_STATE);
    const normalized = {
      ...base,
      ...candidate,
      project: { ...base.project, ...(candidate.project || {}) },
      prototype: { ...base.prototype, ...(candidate.prototype || {}) },
      chat: { ...base.chat, ...(candidate.chat || {}) },
      runs: Array.isArray(candidate.runs) ? candidate.runs.map(normalizeRun) : [],
      decisions: Array.isArray(candidate.decisions) ? candidate.decisions.map(String) : base.decisions,
      pending: Array.isArray(candidate.pending) ? candidate.pending.map(String) : base.pending,
      sources: Array.isArray(candidate.sources) ? candidate.sources.map(normalizeSource) : base.sources,
      events: Array.isArray(candidate.events) ? candidate.events.map(normalizeEvent) : base.events,
      inheritance: String(candidate.inheritance || ""),
      inheritanceRecord: normalizeInheritanceRecord(candidate.inheritanceRecord)
    };
    if (!normalized.runs.some((run) => run.id === normalized.selectedRunId)) {
      normalized.selectedRunId = normalized.runs.at(-1)?.id || null;
    }
    normalized.executionStatus = deriveExecutionStatus(normalized.runs);
    updateNameFor(normalized);
    return normalized;
  }

  function normalizeImportedState(candidate) {
    const normalized = normalizeState(candidate);
    const originalStatus = normalized.chat.status;
    normalized.chat.status = "ON";
    normalized.chat.closedAt = null;
    normalized.chat.closeReason = "";
    normalized.inheritance = "";
    normalized.inheritanceRecord = null;
    normalized.runs = normalized.runs.map((run) => {
      run.product.artifact = null;
      run.evidence.artifact = null;
      run.verificationStatus = deriveVerificationStatus(run);
      return run;
    });
    normalized.executionStatus = deriveExecutionStatus(normalized.runs);
    normalized.pending.unshift(`IMPORTACIÓN · Estado ${originalStatus} reabierto como ON; readjuntar archivos para recuperar verificación material.`);
    normalized.events = normalized.events.filter((event) => event.type !== "STATE_TRANSITION");
    updateNameFor(normalized);
    return normalized;
  }

  function normalizeRun(run, index) {
    const agent = AGENTS.some((item) => item.code === run?.agent) ? run.agent : "EJEC";
    const intent = String(run?.intent || "");
    const defaultActions = agentActions(agent, intent);
    return {
      id: String(run?.id || `RUN-IMPORTED-${index + 1}`),
      sequence: Number(run?.sequence || index + 1),
      intent,
      agent,
      createdAt: isValidIsoDate(run?.createdAt) ? run.createdAt : null,
      responsePlain: String(run?.responsePlain || ""),
      response: {
        actions: Array.isArray(run?.response?.actions) ? run.response.actions.map(String) : defaultActions,
        nextAgent: String(run?.response?.nextAgent || recommendedNext(agent)),
        limit: String(run?.response?.limit || "Salida estructurada importada; no contiene HTML activo.")
      },
      product: {
        name: String(run?.product?.name || ""),
        type: String(run?.product?.type || ""),
        reference: String(run?.product?.reference || ""),
        description: String(run?.product?.description || ""),
        artifact: normalizeArtifact(run?.product?.artifact)
      },
      evidence: {
        testName: String(run?.evidence?.testName || ""),
        testStatus: ["PENDING", "PASS", "FAIL"].includes(run?.evidence?.testStatus) ? run.evidence.testStatus : "PENDING",
        result: String(run?.evidence?.result || ""),
        artifact: normalizeArtifact(run?.evidence?.artifact)
      },
      verificationStatus: VERIFICATION_STATUSES.includes(run?.verificationStatus) ? run.verificationStatus : "PENDING"
    };
  }

  function normalizeArtifact(artifact) {
    if (!artifact || typeof artifact !== "object") return null;
    return {
      fileName: String(artifact.fileName || ""),
      size: Number(artifact.size || 0),
      mimeType: String(artifact.mimeType || "application/octet-stream"),
      sha256: String(artifact.sha256 || "").toLowerCase(),
      verifiedAt: artifact.verifiedAt || null,
      source: artifact.source === "LOCAL_FILE" ? "LOCAL_FILE" : "UNTRUSTED"
    };
  }

  function normalizeSource(source) {
    return {
      id: String(source?.id || "SOURCE"),
      label: String(source?.label || "Fuente sin nombre"),
      status: ["VERIFIED", "DECLARED", "STALE"].includes(source?.status) ? source.status : "DECLARED",
      note: String(source?.note || "")
    };
  }

  function normalizeEvent(event, index) {
    return {
      id: String(event?.id || `EVT-IMPORTED-${index + 1}`),
      type: String(event?.type || "IMPORTED_EVENT"),
      at: isValidIsoDate(event?.at) ? event.at : null,
      detail: safeJsonValue(event?.detail)
    };
  }

  function normalizeInheritanceRecord(record) {
    if (!record || typeof record !== "object") return null;
    return {
      runId: String(record.runId || ""),
      productSha256: String(record.productSha256 || "").toLowerCase(),
      evidenceSha256: String(record.evidenceSha256 || "").toLowerCase(),
      decisions: Array.isArray(record.decisions) ? record.decisions.map(String) : [],
      pending: Array.isArray(record.pending) ? record.pending.map(String) : [],
      generatedAt: record.generatedAt || null,
      text: String(record.text || "")
    };
  }

  function updateNameFor(target) {
    const code = sanitizeSegment(target.project.code, "IALP");
    const objectName = sanitizeSegment(target.chat.object, "InterfazMinima");
    const version = sanitizeVersion(target.prototype.version);
    const cycle = sanitizeCycle(target.chat.cycle);
    target.project.code = code;
    target.chat.object = objectName;
    target.prototype.version = version;
    target.chat.cycle = cycle;
    target.chat.name = `${code}-${target.chat.agent}-${objectName}-${version}-${target.chat.status}-${cycle}`;
  }

  function loadState() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return deepClone(INITIAL_STATE);
      const parsed = JSON.parse(raw);
      const validation = validateState(parsed, { source: "storage" });
      if (!validation.ok) {
        console.warn("Estado local incompatible; se restaura v0.3", validation.errors);
        return deepClone(INITIAL_STATE);
      }
      return normalizeState(parsed);
    } catch (error) {
      console.warn("No se pudo cargar el estado local", error);
      return deepClone(INITIAL_STATE);
    }
  }

  function queueSave() {
    updateSaveLabel("Cambios pendientes…");
    clearTimeout(saveTimer);
    saveTimer = setTimeout(saveState, 250);
  }

  function saveState() {
    state.updatedAt = new Date().toISOString();
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
      updateSaveLabel("Guardado localmente");
    } catch (error) {
      console.warn("Almacenamiento local no disponible", error);
      updateSaveLabel("Activo solo en esta sesión");
    }
  }

  function exportState() {
    saveState();
    const validation = validateState(state, { source: "export" });
    if (!validation.ok) {
      showToast("Exportación bloqueada: estado incompatible");
      return;
    }
    const blob = new Blob([JSON.stringify(state, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `${state.chat.name}.json`;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    URL.revokeObjectURL(url);
    showToast("Estado v0.3 exportado");
  }

  function resetState() {
    try { localStorage.removeItem(STORAGE_KEY); } catch (error) { console.warn(error); }
    state = deepClone(INITIAL_STATE);
    ensureRuntimeDates();
    saveState();
    renderAll();
    showToast("Estado restaurado desde la fuente inicial única");
  }

  function ensureRuntimeDates() {
    if (!state.events[0]?.at) state.events[0].at = new Date().toISOString();
    updateChatName();
  }

  function selectedRun() {
    return state.runs.find((run) => run.id === state.selectedRunId) || null;
  }

  function evidenceControls() {
    return [
      el.productNameInput, el.productTypeInput, el.productReferenceInput, el.productDescriptionInput,
      el.productArtifactInput, el.testNameInput, el.testStatusSelect, el.testEvidenceInput, el.evidenceArtifactInput
    ];
  }

  function clearFileInputs() {
    if (el.productArtifactInput) el.productArtifactInput.value = "";
    if (el.evidenceArtifactInput) el.evidenceArtifactInput.value = "";
  }

  function isLocked() {
    return FINAL_STATUSES.has(state.chat.status);
  }

  function nonEmpty(items) {
    return Array.isArray(items) && items.some((item) => String(item || "").trim());
  }

  function addEvent(type, detail) {
    state.events.push({
      id: `EVT-${String(state.events.length + 1).padStart(4, "0")}`,
      type,
      at: new Date().toISOString(),
      detail: safeJsonValue(detail)
    });
  }

  function createRunId(sequence) {
    const stamp = new Date().toISOString().replace(/[-:.TZ]/g, "").slice(0, 14);
    return `RUN-${stamp}-${String(sequence).padStart(3, "0")}`;
  }

  function agentByCode(code) {
    return AGENTS.find((agent) => agent.code === code) || AGENTS.at(-1);
  }

  function sanitizeSegment(value, fallback) {
    const clean = String(value || "").trim().replace(/[^A-Za-z0-9_]/g, "");
    return clean || fallback;
  }

  function sanitizeVersion(value) {
    const clean = String(value || "").trim().replace(/[^A-Za-z0-9._-]/g, "");
    return clean || "v0.3";
  }

  function sanitizeCycle(value) {
    const clean = String(value || "").trim().toUpperCase().replace(/[^A-Z0-9]/g, "");
    return clean || "C06";
  }

  function artifactLabel(artifact) {
    if (!materialArtifactComplete(artifact)) return "Sin archivo verificado.";
    return `${artifact.fileName} · ${formatBytes(artifact.size)} · SHA-256 ${artifact.sha256}`;
  }

  function formatBytes(bytes) {
    const value = Number(bytes || 0);
    if (value < 1024) return `${value} B`;
    if (value < 1024 * 1024) return `${(value / 1024).toFixed(1)} KB`;
    return `${(value / (1024 * 1024)).toFixed(1)} MB`;
  }

  function formatDate(value) {
    if (!value) return "sin fecha";
    try {
      return new Intl.DateTimeFormat("es-ES", { dateStyle: "short", timeStyle: "short" }).format(new Date(value));
    } catch {
      return String(value);
    }
  }

  function isValidIsoDate(value) {
    return typeof value === "string" && value.length >= 20 && !Number.isNaN(Date.parse(value));
  }

  function safeJsonValue(value) {
    try { return JSON.parse(JSON.stringify(value)); } catch { return String(value); }
  }

  function updateSaveLabel(text) {
    el.saveState.textContent = text;
  }

  async function copyText(text, successMessage) {
    if (!text) {
      showToast("No hay contenido para copiar");
      return;
    }
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      const area = document.createElement("textarea");
      area.value = text;
      document.body.appendChild(area);
      area.select();
      document.execCommand("copy");
      area.remove();
    }
    showToast(successMessage);
  }

  function showToast(message) {
    el.toast.textContent = message;
    el.toast.classList.add("visible");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.toast.classList.remove("visible"), 2300);
  }

  function deepClone(value) {
    return typeof structuredClone === "function" ? structuredClone(value) : JSON.parse(JSON.stringify(value));
  }

  function exposeTestApi() {
    window.__IALP_TEST__ = Object.freeze({
      storageKey: STORAGE_KEY,
      schemaVersion: SCHEMA_VERSION,
      getState: () => deepClone(state),
      validateState,
      normalizeImportedState: (candidate) => deepClone(normalizeImportedState(candidate)),
      isLocked: () => isLocked(),
      materialArtifactComplete,
      deriveVerificationStatus
    });
  }
})();
