# Correcciones aplicadas desde CRIT C05

| Hallazgo C05 | Corrección v0.3 | Estado |
|---|---|---|
| XSS mediante `responseHtml` | Campo prohibido; renderizado desde estructura con `textContent`. | CERRADO |
| HANDOFF fabricado importado | Validación completa y normalización obligatoria a `ON`. | CERRADO |
| Evidencia meramente declarativa | Dos selectores de archivo y SHA-256; estado separado `EVIDENCE_DECLARED`. | CERRADO EN IMPLEMENTACIÓN |
| Persistencia HTTP real | Test E2E con servidor y recarga nativa incluido. Chromium del entorno está bloqueado por política. | PREPARADO; VERIFICACIÓN EXTERNA PENDIENTE |
| Pruebas destructivas | Salida a `IALP_TEST_OUTPUT` o `/tmp`; no altera el paquete. | CERRADO |
