# Herencia contextual · v0.3

La herencia se genera únicamente desde una ejecución `VERIFIED_MATERIAL`.

`inheritanceRecord` registra:

- ID de ejecución;
- SHA-256 del producto;
- SHA-256 de la evidencia;
- copia exacta de decisiones;
- copia exacta de pendientes;
- fecha de generación;
- texto exacto de herencia.

Modificar producto, evidencia, identidad, decisiones o pendientes invalida la herencia. HANDOFF compara de nuevo todos los campos. La importación siempre elimina la herencia y obliga a regenerarla localmente.
