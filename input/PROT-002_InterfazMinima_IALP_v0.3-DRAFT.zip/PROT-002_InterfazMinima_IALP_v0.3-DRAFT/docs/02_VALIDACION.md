# Validación técnica · PROT-002 v0.3

## Regresión automatizada

- sintaxis y referencias;
- ausencia del sumidero `innerHTML = responseHtml`;
- rechazo explícito de `responseHtml` importado;
- rechazo de HANDOFF sin fecha, motivo, transición o herencia estructurada;
- degradación de cualquier importación final a `ON`;
- degradación de evidencia importada a `EVIDENCE_DECLARED`;
- cálculo SHA-256 de archivo de producto y archivo de prueba;
- HANDOFF únicamente desde `VERIFIED_MATERIAL`;
- herencia vinculada a ambos hashes;
- recorrido móvil sin desbordamiento;
- resultados y capturas fuera del árbol fuente.

## Persistencia HTTP

`tests/http_persistence_test.py` levanta un servidor HTTP real, comprueba la carga con `urllib`, abre la misma URL con Chromium, escribe en `localStorage`, recarga y compara el valor persistido.

En este entorno, la fase HTTP del servidor pasa, pero Chromium aplica la política administrada `URLBlocklist: ["*"]` y devuelve `ERR_BLOCKED_BY_ADMINISTRATOR` incluso para localhost. El test registra el bloqueo y no lo declara como verificación nativa.
