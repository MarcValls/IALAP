# Correcciones aplicadas desde CRIT C03

| Hallazgo | Corrección v0.2 |
|---|---|
| CRITICAL-01 · Estados editables | Estado de chat de solo lectura y transiciones controladas. |
| CRITICAL-02 · Intención confundida con producto | Formulario independiente de producto y evidencia; herencia basada en esos campos. |
| CRITICAL-03 · Fuentes de verdad incompatibles | Eliminado `initial_state.json`; `initial_state.js` gobierna reset e inicio. |
| CRITICAL-04 · Nomenclatura no confirmada | `codeStatus = PROVISIONAL`, aviso visible y bloqueo de importaciones que pretendan consolidarla. |
| HIGH-01 · Fuentes activas ficticias | Renombradas a fuentes declaradas, con estado y nota de conflicto. |
| HIGH-02 · Sin importación | Importación JSON con validación, vista previa y confirmación. |
| HIGH-03 · Persistencia no probada | E2E con servidor HTTP, recarga y comparación del estado. |
| HIGH-04 · Segunda operación sin traza | ID, ejecución, pendiente y evidencia independientes por operación. |
| HIGH-05 · Operación tardía en móvil | DOM y orden responsive sitúan la operación primero. |
| MEDIUM-01 · Objeto codificado | Campo de objeto explícito y nombre regenerado desde datos controlados. |
| MEDIUM-02 · Evidencia mutable tras cierre | HANDOFF/OFF deshabilitan controles y preservan eventos. |
| MEDIUM-03 · Apariencia de agente real | Aviso persistente “SIMULACIÓN LOCAL · SIN MODELO EXTERNO”. |
| MEDIUM-04 · Criterio invisible | Checklist visible de cinco condiciones para HANDOFF. |
