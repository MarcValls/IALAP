# Especificación funcional · PROT-002 v0.3

## Alcance

Interfaz web estática para controlar un ciclo regenerativo mínimo. No incluye modelo de lenguaje, backend, memoria MCP ni PROT-003.

## Modelo de estado

```json
{
  "chat": { "status": "ON | HANDOFF | OFF" },
  "prototype": {
    "artifactMaturity": "DRAFT",
    "validationStatus": "PENDING_USER"
  },
  "executionStatus": "NOT_RUN | EXECUTED | EVIDENCE_DECLARED | VERIFIED_MATERIAL"
}
```

Cada ejecución usa:

```json
{
  "verificationStatus": "PENDING | EVIDENCE_DECLARED | VERIFIED_MATERIAL | FAIL",
  "product": { "artifact": { "fileName": "...", "sha256": "...", "source": "LOCAL_FILE" } },
  "evidence": { "artifact": { "fileName": "...", "sha256": "...", "source": "LOCAL_FILE" } }
}
```

## Importación

- Solo esquema `3.0.0`.
- `responseHtml` está prohibido.
- La respuesta importable es texto estructurado: `actions`, `nextAgent` y `limit`.
- Un HANDOFF u OFF debe ser internamente coherente para ser leído.
- Todo archivo aceptado se normaliza después a `ON`.
- Los artefactos importados pierden `LOCAL_FILE`, hashes confiables, herencia y transición final.

## HANDOFF

Exige:

1. ejecución seleccionada;
2. producto textual completo y archivo SHA-256;
3. prueba `PASS` y archivo de evidencia SHA-256;
4. decisiones y pendientes;
5. `inheritanceRecord` coherente con ejecución, hashes y continuidad.
