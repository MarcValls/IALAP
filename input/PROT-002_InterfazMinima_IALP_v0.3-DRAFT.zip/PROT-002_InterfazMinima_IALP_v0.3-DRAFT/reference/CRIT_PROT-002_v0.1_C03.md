# CRIT · Revisión de PROT-002 Interfaz mínima

Nombre del ciclo: `IALP-CRIT-InterfazMinima-v0.1-HANDOFF-C03`

Objeto revisado: `PROT-002_InterfazMinima_IALP_v0.1.zip`

Estado recibido: DRAFT funcional, preparado, ejecutado y técnicamente verificado; validación del usuario pendiente.

## Veredicto

**NO-GO para VALIDADO o CANON.**

**GO condicionado para una iteración correctiva `v0.2-DRAFT`.**

El prototipo demuestra que la interfaz puede renderizarse y que las interacciones básicas funcionan. Sin embargo, no protege la coherencia del ciclo: permite entregar sin producto, ejecutar después del cierre y declararse CANON sin validación. La interfaz representa estados, pero no los gobierna.

## Comprobaciones superadas

- El ZIP no está corrupto.
- El manifiesto SHA-256 coincide con todos los archivos.
- La sintaxis JavaScript es válida.
- El JSON inicial es válido como archivo.
- No hay IDs HTML duplicados.
- La pantalla renderiza en escritorio y móvil.
- No se detectó desbordamiento horizontal en la prueba móvil.
- Ejecutar, editar listas, preparar HANDOFF y exportar JSON producen respuesta de interfaz.
- La entrada del usuario se escapa antes de insertarse como HTML.

Estas pruebas acreditan funcionamiento técnico básico. No acreditan cierre semántico ni validez del producto.

## Hallazgos bloqueantes

### CRITICAL-01 · No existe una máquina de estados real

Evidencia:

- `HANDOFF` puede activarse sin haber ejecutado una operación.
- `OFF` no bloquea los campos ni el botón Ejecutar.
- `CANON` aparece como opción ordinaria del selector y puede elegirse directamente.
- Después de cerrar el ciclo se puede generar una respuesta nueva manteniendo el estado `OFF`.

Impacto:

Los estados se convierten en etiquetas editables. No representan una condición verificable del ciclo y pueden afirmar cierre o consolidación sin evidencia.

Corrección obligatoria:

- Implementar transiciones permitidas.
- Impedir HANDOFF sin resultado, decisiones, pendientes y herencia mínima.
- Bloquear edición y ejecución en OFF y CANON.
- Excluir CANON del selector operativo ordinario.
- Exigir una acción de validación separada y autorizada para consolidar.

### CRITICAL-02 · “Resultado producido” no representa un producto

En `assets/app.js`, `buildInheritance()` extrae la línea `OPERACIÓN:` de la respuesta y la presenta como `Resultado producido`.

Resultado observado:

`Resultado producido: Ejecutar tras cierre`

Impacto:

La herencia confunde intención con producto. Esto permite declarar un resultado inexistente y contradice la distinción entre preparado, ejecutado, verificado y validado.

Corrección obligatoria:

El cierre debe registrar por separado:

- operación solicitada;
- producto generado;
- ruta o referencia del artefacto;
- prueba ejecutada;
- evidencia obtenida;
- estado de validación.

Si no existe producto, la interfaz debe impedir el HANDOFF o marcar explícitamente `sin producto`.

### CRITICAL-03 · Hay tres verdades incompatibles sobre el estado

Evidencia:

- `README.md`: “DRAFT funcional”.
- `data/initial_state.json`: `prototype.status = DRAFT`.
- `assets/app.js`: `prototype.status = ON` y `chat.status = ON`.
- `data/initial_state.json` no es cargado por la aplicación; solo lo comprueba el smoke test.

Impacto:

El archivo presentado como estado inicial no gobierna la aplicación. El reset usa otro estado embebido. La exportación puede mezclar madurez del prototipo y estado operativo del chat.

Corrección obligatoria:

- Establecer una única fuente de verdad.
- Cargar `initial_state.json` o eliminarlo.
- Separar `chat_status` de `artifact_maturity` y `validation_status`.
- Definir migración/versionado del esquema persistido.

### CRITICAL-04 · Se operacionaliza una nomenclatura aún no confirmada

La documentación declara provisional la separación:

- `IALP` como código del proyecto.
- `SRG` como metodología.

Sin embargo, la aplicación la fija como valor operativo y regenera automáticamente todos los nombres con `IALP`.

Impacto:

Una propuesta todavía pendiente se convierte en comportamiento por defecto y puede propagarse a exportaciones y herencias como si fuese canon.

Corrección obligatoria:

Marcar la nomenclatura como provisional en los datos y evitar regeneraciones irreversibles hasta que exista decisión confirmada. Alternativamente, validar primero la decisión y registrarla en la memoria canónica.

## Hallazgos altos

### HIGH-01 · Las “fuentes activas” no son fuentes verificadas

La lista es un array estático. No hay carga, lectura, versión, fecha, disponibilidad ni comprobación de autoridad. Además, incluye `08 · Memoria del proyecto`, conocida como desactualizada respecto a PROT-001 y PROT-002.

Corrección:

Cambiar el nombre a `Fuentes declaradas` o implementar metadatos reales: referencia, versión, estado, verificación y conflictos.

### HIGH-02 · El flujo de continuidad solo exporta; no puede reanudarse

Existe exportación JSON, pero no importación. El estado queda limitado al mismo navegador o a una inspección manual del archivo.

Corrección:

Añadir importación con validación de esquema, vista previa, detección de versión y confirmación antes de reemplazar el estado local.

### HIGH-03 · La prueba de persistencia no se ejecutó

`tests/browser_test.py` incrusta HTML, CSS y JavaScript mediante `set_content`. Este método verifica interacción, pero no carga real de archivos, origen HTTP ni persistencia después de recarga.

Corrección:

Añadir una prueba E2E contra un servidor local o entorno de preview que verifique:

- carga de recursos;
- escritura en localStorage;
- recarga;
- recuperación exacta del estado;
- migración de esquema;
- reset.

### HIGH-04 · La trazabilidad de operaciones se pierde después de la primera

La aplicación solo añade un pendiente de validación cuando no existe ningún texto que contenga `Validar el resultado`. Al ejecutar una segunda operación, no se crea su pendiente específico.

Corrección:

Asignar ID a cada ejecución y registrar un evento o pendiente por operación, no por coincidencia textual global.

### HIGH-05 · El orden móvil retrasa la tarea principal

En móvil aparecen primero ciclo, fuentes y flujo heredado. El usuario debe recorrer una pantalla extensa antes de llegar a la entrada y al botón Ejecutar.

Corrección:

Mostrar primero operación y respuesta. Contexto, fuentes y flujo deben quedar plegados o accesibles desde una sección secundaria.

## Hallazgos medios

### MEDIUM-01 · El nombre del objeto está codificado

`updateChatNameFromFields()` fuerza siempre `InterfazMinima`. La pantalla parece permitir editar el nombre del chat, pero cualquier cambio posterior de agente, estado, versión o ciclo reconstruye el nombre y elimina otro objeto introducido manualmente.

### MEDIUM-02 · Los estados finales no inmovilizan la evidencia

Incluso si se bloqueara la ejecución, decisiones, pendientes e herencia deberían quedar congelados o versionados después del cierre. Actualmente no existe historial de modificaciones.

### MEDIUM-03 · La interfaz puede confundirse con un agente real

El texto aclara que la salida es local, pero los rótulos `Ejecutar ciclo` y `Respuesta del agente` conservan una apariencia operativa fuerte. Debe mostrarse de forma persistente `Simulación local` en la cabecera del área de respuesta.

### MEDIUM-04 · El cierre carece de criterio visible

El usuario no sabe qué condiciones faltan para habilitar HANDOFF, OFF o validación. La interfaz necesita una lista breve de requisitos de cierre con estado comprobado.

## Plan mínimo de corrección

### RC-01 · Modelo de estado

Crear campos separados:

```json
{
  "chat_status": "ON",
  "artifact_maturity": "DRAFT",
  "execution_status": "VERIFIED",
  "validation_status": "PENDING_USER"
}
```

Los nombres exactos son propuestos; la separación conceptual es obligatoria.

### RC-02 · Guardas de transición

- ON → HANDOFF: solo con operación ejecutada, producto/evidencia y herencia.
- ON → OFF: cierre explícito con motivo.
- HANDOFF/OFF: solo lectura.
- CANON: fuera del selector ordinario; requiere validación registrada.

### RC-03 · Evidencia de producto

Añadir campos obligatorios para producto, referencia, prueba y resultado de prueba.

### RC-04 · Fuente única de estado

Usar un único estado inicial, cargado por la aplicación y versionado.

### RC-05 · Continuidad reversible

Añadir importación JSON segura y validada.

### RC-06 · QA de cierre

Añadir pruebas automáticas para:

- HANDOFF sin operación: debe fallar.
- ejecución en OFF: debe fallar.
- CANON directo: debe fallar.
- segunda operación: debe crear trazabilidad propia.
- persistencia tras recarga: debe conservar el estado.
- importación incompatible: debe rechazarse.

### RC-07 · Ruta principal móvil

Colocar la operación antes del contexto y plegar fuentes/arquitectura.

## Criterio de aceptación de v0.2

PROT-002 podrá pasar de revisión CRIT cuando:

1. Ningún estado final pueda declararse sin guardas.
2. OFF y CANON sean inmutables dentro del ciclo cerrado.
3. El resultado producido señale un producto o evidencia real, no la intención.
4. Exista una única fuente de verdad del estado.
5. La nomenclatura provisional no se propague como canon.
6. Cada ejecución tenga trazabilidad propia.
7. La persistencia se haya probado realmente tras recarga.
8. La operación principal sea el primer recorrido útil en móvil.

## Estado resultante

- Preparado: sí.
- Ejecutado: sí.
- Verificado técnicamente: parcialmente suficiente.
- Verificado semánticamente: no.
- Validado: no.
- CANON: no.
- Estado recomendado del artefacto: `v0.1-DRAFT`.
- Siguiente ciclo: corrección EJEC `v0.2-DRAFT`.

## Cierre de agente

Estado del agente CRIT: `HANDOFF`.

Siguiente agente recomendado: `EJEC · Agente Ejecutor`.

Instrucción:

Corregir PROT-002 sin ampliar todavía el núcleo ni conectar un modelo externo. Priorizar máquina de estados, evidencia de producto, fuente única de datos, nomenclatura provisional, persistencia comprobable y ruta móvil. Entregar `PROT-002_InterfazMinima_IALP_v0.2-DRAFT` con pruebas de regresión.

```text
<<SRG:MEM_UPDATE>>
Origen:
IALP-CRIT-InterfazMinima-v0.1-HANDOFF-C03

Definido:
PROT-002 v0.1 funciona técnicamente como interfaz estática, pero no satisface integridad de estados ni evidencia de cierre.

Propuesto:
Crear PROT-002 v0.2 correctivo antes de iniciar PROT-003.

Pendiente:
Implementar guardas de estado, fuente única de datos, evidencia real de producto, importación JSON, trazabilidad por ejecución, prueba real de persistencia y mejora móvil.

Descartado:
Declarar PROT-002 v0.1 VALIDADO o CANON.
Iniciar PROT-003 antes de corregir los fallos bloqueantes de PROT-002.

Riesgos:
La versión actual permite HANDOFF sin producto, ejecución en OFF y CANON directo.
La nomenclatura IALP/SRG sigue sin confirmación canónica.

Próxima acción:
EJEC debe producir PROT-002 v0.2-DRAFT y ejecutar pruebas de regresión sobre los hallazgos CRITICAL y HIGH.

Siguiente agente recomendado:
EJEC
<</SRG:MEM_UPDATE>>
```
