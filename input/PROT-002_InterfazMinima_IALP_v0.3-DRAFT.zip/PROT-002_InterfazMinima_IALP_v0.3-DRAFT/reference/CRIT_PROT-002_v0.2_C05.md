# CRIT · Revisión de PROT-002 Interfaz mínima v0.2

Nombre del ciclo: `IALP-CRIT-InterfazMinima-v0.2-HANDOFF-C05`

Objeto revisado: `PROT-002_InterfazMinima_IALP_v0.2-DRAFT.zip`

Base de contraste: hallazgos CRITICAL y HIGH de `IALP-CRIT-InterfazMinima-v0.1-HANDOFF-C03`.

Fecha: 2026-07-22.

## Veredicto

**NO-GO para VALIDADO, CANON o inicio de PROT-003.**

**GO condicionado para una nueva corrección de PROT-002, recomendada como `v0.3-DRAFT`.**

v0.2 corrige de forma sustancial el flujo ordinario: separa estados, elimina CANON, incorpora guardas, trazabilidad, producto/evidencia, importación y una ruta móvil mejor. Sin embargo, tres condiciones de cierre continúan abiertas y una de ellas introduce una vulnerabilidad crítica en la importación.

## Matriz de cierre de C03

| Hallazgo C03 | Estado en v0.2 | Dictamen |
|---|---|---|
| CRITICAL-01 · Máquina de estados | Corregido en la interfaz ordinaria, pero el importador acepta un HANDOFF fabricado sin `closedAt`, `closeReason` ni herencia íntegra. | PARCIAL |
| CRITICAL-02 · Intención confundida con producto | Se separan campos, pero cualquier texto puede presentarse como producto/evidencia PASS sin comprobación material de la referencia o prueba. | PARCIAL |
| CRITICAL-03 · Fuentes de verdad incompatibles | `initial_state.js` gobierna inicio y reset; los estados conceptuales están separados. | CORREGIDO |
| CRITICAL-04 · Nomenclatura no confirmada | `codeStatus = PROVISIONAL`, aviso visible y bloqueo de importación como canon. | CORREGIDO |
| HIGH-01 · Fuentes ficticias | Renombradas a fuentes declaradas y clasificadas como VERIFIED, DECLARED o STALE. | CORREGIDO |
| HIGH-02 · Sin importación | Existe importación con vista previa, pero `responseHtml` importado se inserta con `innerHTML` y permite ejecución de JavaScript. | NO CERRADO / NUEVO CRÍTICO |
| HIGH-03 · Persistencia no probada | Solo se verifica una imitación de `localStorage`; la recarga HTTP nativa sigue declarada como pendiente. | NO CORREGIDO |
| HIGH-04 · Trazabilidad perdida | Cada ejecución recibe ID y pendiente propios. | CORREGIDO |
| HIGH-05 · Operación tardía en móvil | La operación aparece antes que identidad, fuentes y flujo contextual. | CORREGIDO |

## Pruebas independientes

### Pruebas del paquete

Superadas:

- `tests/smoke_test.py`.
- `tests/browser_test.py`.
- Integridad del ZIP.
- Manifiesto SHA-256 del paquete recién extraído.

Nota: ejecutar `browser_test.py` reescribe las capturas dentro del árbol extraído y, por tanto, invalida después el manifiesto de ese árbol. El ZIP original sí coincide con su manifiesto. La prueba debería escribir sus capturas en un directorio temporal o regenerar el manifiesto solo durante el empaquetado.

### ADV-01 · HANDOFF fabricado mediante importación

Se construyó un estado con:

- `chat.status = HANDOFF`;
- `closedAt = null`;
- `closeReason = ""`;
- una ejecución declarada PASS mediante texto;
- una herencia cuyo contenido completo era únicamente el ID de ejecución.

Resultado de `validateState()`:

```json
{"ok": true, "errors": []}
```

Conclusión: el importador no acredita una transición real ni verifica que la herencia contenga el producto, prueba, evidencia, decisiones y pendientes. Solo comprueba que la cadena incluya el ID seleccionado.

### ADV-02 · Ejecución de JavaScript desde JSON importado

Se importó una ejecución cuyo `responseHtml` contenía:

```html
<img src=x onerror="window.__PROT002_XSS__=true">
```

Resultados:

```text
XSS_IMPORT_ACCEPTED = true
XSS_EXECUTED = true
```

Causa:

- `normalizeRun()` conserva `responseHtml` importado.
- `renderResponse()` lo asigna mediante `innerHTML`.
- `validateState()` no rechaza ni sanea HTML importado.

Impacto:

Un JSON manipulado puede ejecutar JavaScript en el origen local de la aplicación, leer o alterar el estado persistido y falsificar la interfaz. Este hallazgo bloquea la validación de v0.2.

### ADV-03 · Evidencia declarativa sin comprobación material

La aplicación habilita PASS y HANDOFF cuando producto, ruta, prueba y resultado contienen texto no vacío. No comprueba:

- que la ruta exista;
- que el artefacto sea accesible;
- que la prueba haya sido ejecutada;
- que la evidencia corresponda al producto;
- que exista hash, archivo adjunto o resultado reproducible.

La separación semántica está corregida, pero la verificación continúa siendo declarativa.

### ADV-04 · Persistencia real

La propia documentación de v0.2 declara pendiente la recarga bajo un origen HTTP con `localStorage` nativo. La prueba automática reemplaza `localStorage` por una implementación de memoria y reinicializa el documento mediante `set_content`.

Por tanto, no se satisface el criterio 7 de aceptación de C03: persistencia probada realmente tras recarga.

## Correcciones obligatorias

### RC-08 · Importación segura

Una de estas estrategias es obligatoria:

1. Eliminar `responseHtml` del esquema importable y reconstruir la respuesta desde datos estructurados; opción recomendada.
2. O sanear HTML con una política estricta que elimine atributos de evento, URLs peligrosas, scripts, SVG activo, iframes y elementos ejecutables.

El estado importado nunca debe insertar HTML arbitrario mediante `innerHTML`.

### RC-09 · Validación completa de HANDOFF importado

Para importar un estado HANDOFF debe exigirse:

- `closedAt` válido;
- `closeReason` no vacío;
- evento `STATE_TRANSITION` coherente;
- ejecución seleccionada PASS;
- producto y evidencia completos;
- herencia estructurada y vinculada, no mera coincidencia de texto;
- correspondencia entre los datos de la ejecución y los campos de herencia.

Alternativa más segura: importar siempre como `ON` y exigir que el usuario prepare el HANDOFF localmente.

### RC-10 · Evidencia verificable

Añadir al menos uno de estos mecanismos:

- selector de archivo y hash SHA-256;
- referencia resoluble y comprobación de existencia;
- resultado de prueba importado desde un archivo firmado o generado por el runner;
- registro automático de comando, código de salida, fecha y artefacto comprobado.

Mientras no exista, la interfaz debe denominar el estado `EVIDENCE_DECLARED`, no `VERIFIED` ni PASS material.

### RC-11 · Persistencia HTTP real

Ejecutar una prueba E2E en un entorno que permita un origen estable:

1. cargar recursos mediante HTTP;
2. crear una ejecución;
3. guardar producto y evidencia;
4. recargar la misma URL;
5. comparar el estado recuperado;
6. comprobar HANDOFF y OFF después de recarga;
7. probar migración y reset.

Si el entorno actual lo bloquea, la verificación debe realizarse en otro entorno antes de declarar el criterio cerrado.

### RC-12 · Pruebas no destructivas

`browser_test.py` no debe sobrescribir archivos cubiertos por `MANIFEST.sha256`. Las capturas de ejecución deben ir a un directorio temporal o de resultados fuera del paquete fuente.

## Estado resultante

- Preparado: sí.
- Ejecutado: sí.
- Verificado funcionalmente en flujo ordinario: sí.
- Verificado adversarialmente: no; falló importación segura y cierre importado.
- Persistencia HTTP nativa verificada: no.
- Validado: no.
- CANON: no.
- Madurez correcta: `DRAFT`.
- PROT-003: bloqueado.

## Cierre de agente

Estado del agente CRIT: `HANDOFF`.

Siguiente agente recomendado: `EJEC · Agente Ejecutor`.

Instrucción:

Corregir PROT-002 como v0.3-DRAFT sin iniciar PROT-003. Eliminar HTML ejecutable de importación, endurecer HANDOFF importado, distinguir evidencia declarada de evidencia material, verificar persistencia HTTP real y hacer las pruebas no destructivas.

```text
<<SRG:MEM_UPDATE>>
Origen:
IALP-CRIT-InterfazMinima-v0.2-HANDOFF-C05

Definido:
PROT-002 v0.2 corrige CRITICAL-03, CRITICAL-04, HIGH-01, HIGH-04 y HIGH-05.
El flujo ordinario de CRITICAL-01 está corregido.

Propuesto:
Crear PROT-002 v0.3-DRAFT como iteración correctiva de seguridad e integridad.

Pendiente:
Eliminar XSS por responseHtml importado.
Impedir HANDOFF fabricado mediante importación.
Acreditar evidencia material o renombrarla como declarada.
Verificar localStorage nativo después de recarga HTTP.
Hacer las pruebas no destructivas respecto al manifiesto.

Descartado:
Declarar PROT-002 v0.2 VALIDADO o CANON.
Iniciar PROT-003.

Riesgos:
JSON importado puede ejecutar JavaScript.
HANDOFF importado puede carecer de transición y herencia real.
PASS continúa basado en campos declarativos.
Persistencia HTTP real no acreditada.

Próxima acción:
EJEC debe producir PROT-002 v0.3-DRAFT y superar regresión funcional y adversarial.

Siguiente agente recomendado:
EJEC
<</SRG:MEM_UPDATE>>
```
