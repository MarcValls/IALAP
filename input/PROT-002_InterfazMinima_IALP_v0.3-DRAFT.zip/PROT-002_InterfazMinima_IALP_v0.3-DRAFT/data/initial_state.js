(() => {
  "use strict";

  const initialState = {
    schemaVersion: "3.0.0",
    project: {
      code: "IALP",
      codeStatus: "PROVISIONAL",
      method: "SRG",
      name: "IA, LA PREGUNTA, PRÁCTICA"
    },
    prototype: {
      id: "PROT-002",
      name: "Interfaz mínima",
      version: "v0.3",
      artifactMaturity: "DRAFT",
      validationStatus: "PENDING_USER"
    },
    chat: {
      object: "InterfazMinima",
      name: "IALP-EJEC-InterfazMinima-v0.3-ON-C06",
      agent: "EJEC",
      status: "ON",
      cycle: "C06",
      closedAt: null,
      closeReason: ""
    },
    executionStatus: "NOT_RUN",
    intent: "",
    runs: [],
    selectedRunId: null,
    decisions: [
      "PROT-001 define el diagrama lógico del sistema.",
      "PROT-002 debe quedar validado antes de iniciar PROT-003.",
      "IALP es un código provisional; SRG identifica la metodología hasta decisión canónica.",
      "Los estados importados nunca conservan un cierre operativo ni evidencia material confiable."
    ],
    pending: [
      "Validación directa del usuario.",
      "Confirmar la nomenclatura del proyecto antes de convertirla en canon.",
      "No iniciar PROT-003 hasta superar revisión CRIT de esta versión.",
      "Verificar persistencia HTTP nativa en un navegador sin política URLBlocklist."
    ],
    inheritance: "",
    inheritanceRecord: null,
    sources: [
      {
        id: "PROT-001",
        label: "PROT-001 · Diagrama lógico",
        status: "VERIFIED",
        note: "Artefacto construido y comprobado técnicamente."
      },
      {
        id: "SRC-01",
        label: "01 · Nomenclatura de agentes",
        status: "DECLARED",
        note: "Fuente de reglas de identificación."
      },
      {
        id: "SRC-02",
        label: "02 · Agentes, roles y estados",
        status: "DECLARED",
        note: "Fuente de roles y estados."
      },
      {
        id: "SRC-03",
        label: "03 · Apertura, cierre y herencia",
        status: "DECLARED",
        note: "Fuente de estructura de continuidad."
      },
      {
        id: "SRC-04",
        label: "04 · Protocolo operativo",
        status: "DECLARED",
        note: "Fuente del bucle operativo."
      },
      {
        id: "SRC-08",
        label: "08 · Memoria del proyecto",
        status: "STALE",
        note: "Desactualizada respecto a PROT-001 y PROT-002; no gobierna el estado actual."
      },
      {
        id: "CRIT-C05",
        label: "CRIT C05 · Revisión de PROT-002 v0.2",
        status: "VERIFIED",
        note: "Define importación segura, evidencia material, persistencia HTTP y pruebas no destructivas."
      }
    ],
    events: [
      {
        id: "EVT-0001",
        type: "STATE_INITIALIZED",
        at: null,
        detail: {
          version: "v0.3",
          status: "ON"
        }
      }
    ],
    updatedAt: null
  };

  window.IALP_INITIAL_STATE = Object.freeze(initialState);
})();
